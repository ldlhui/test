
import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Dimensions,
    DeviceEventEmitter
} from 'react-native';

import { connect } from 'react-redux'; // 引入connect函数
import { NavigationActions } from 'react-navigation';
import *as counterAction from '../../action/counterAction';

import { TabView, TabBar, SceneMap } from 'react-native-tab-view';

import AppStyles from "../../../styles/AppStyles";
import Uncollected from "../../components/uncollected";
import Collected from "../../components/collected3b";

import MyTabBar from '../../unitl/MyTabBar';
const { width, height } = Dimensions.get('window');
import { OrderQuery, DailySum, Update } from "../../api";
class MainPage extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            index: 0,
            routes: [
                { key: 'first', title: 'Uncollected \n Orders' },
                { key: 'second', title: 'Current \n Delivery' },
            ],
            titleNumber: [0, 0],
            deliveredNumber: [0, 0],
            driverTitleNumber: [0, 0],
            newOtherOrderData: null,
            newRightOrderData: null
        };
    }

    static navigationOptions = {
        header: null
    };

    _renderTabBar = props => (
        <TabBar {...props} style={styles.tabbar}
            titleStyle={AppStyles.header}
            titleContent={"Accepted Orders"}
            titleNumber={props.titleNumber}
            NumberStyle={AppStyles.NumberStyle}
            scrollEnabled={false}
            onTabPress={(data) => { this.setState({ index: data }) }}
            labelStyle={styles.label} />
    );

    componentDidMount() {

        // DeviceEventEmitter.addListener('msg', (title) => {
        //     if (title) {
        //         if (title.driverTitleNumber)
        //             this.setState({
        //                 titleNumber: title.driverTitleNumber
        //             });
        //     }
        // });

        
        // global.storage.save({
        //     key: 'chinaT',
        //     data: data,
        //     expires: null
        // });
        global.storage.load({
            key: 'chinaT'
        }).then(data => {
            this.setState({
                titleNumber: data
            })
        })


        global.storage.load({
            key: 'location'
        }).then(locations => {
                OrderQuery({
                    status: "accepted",
                    // shopModel: { shopId: "001bbb" },
                    driverModel: {
                        latitude: locations.latitude,
                        longitude: locations.longitude,
                        name: "Jim",
                        driverId: "d001"
                    }
                }).then((data) => {
                    OrderQuery({
                        status: "collected",
                        shopModel: { shopId: "2321321jb" },
                        driverModel: {
                            latitude: locations.latitude,
                            longitude: locations.longitude,
                            name: "Jim",
                            driverId: "d001"
                        }
                    }).then((otherData) => {
                        // this.props.fucn.asd([data.data.length, otherData.data.length]);
                        // DeviceEventEmitter.emit('msg', {
                        //     driverTitleNumber:  [data.data.length,otherData.data.length]
                        // });
                        this.setState({
                            newRightOrderData: otherData,
                            rightorderSize: otherData.data.length,
                            driverTitleNumber: [data.data.length, otherData.data.length]
                        })
                    });

                    this.setState({
                        newOtherOrderData: data,
                        orderSize: data.data.length
                    })
                });
            }
            , error => {

            });



    }

    logout() {
        this.props.navigation.dispatch(resetAction)
    }

    setTitleNumber = data => {
        // alert("c2123"+JSON.stringify(data));
        this.setState({
            driverTitleNumber: data
        })
        global.storage.save({
            key: 'driverData',
            data: data,
            expires: null
        });
    }

    render() {
        return (<View style={{ width: width, height: height }}>
            <View style={{ width: width, height: height - 70 }}>
                <TabView
                    navigationState={this.state}
                    renderScene={SceneMap({
                        first: Uncollected,
                        second: Collected,
                    },
                    {...this.props},
                    {ddd:{
                        leftData: this.state.newOtherOrderData,
                        rightData: this.state.newRightOrderData
                    },asd:(data)=>{
                        this.setTitleNumber(data)
                    }})}
                    titleNumber={this.state.driverTitleNumber}
                    navigation={this.props.navigation}
                    renderTabBar={this._renderTabBar}
                    onIndexChange={index => this.setState({ index })}
                    initialLayout={{ width: Dimensions.get('window').width, height: 20 }}
                />
            </View>
            <MyTabBar
                tabs={
                    ["Home", "driver", "map", "delivered", "user"]
                }
                {...this.props}
                titleNumber={this.state.titleNumber}
                deliveredNumber={this.state.deliveredNumber}
                driverTitleNumber={this.state.driverTitleNumber}

                activeTab={"driver"}
                goToPage={(data) => {
                    this.setState({
                        activeTab: data
                    })
                    if(data != "driver") this.props.history.push('/' + data);
                }}
            >
            </MyTabBar>
        </View>)
    }
}

export default connect(
    (state) => ({
        count: state.counter.count,
    }),
    (dispatch) => ({
        incrementFn: () => dispatch(counterAction.increment()),
        decrementFn: () => dispatch(counterAction.decrement()),
    })
)(MainPage)

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    tabbar: {
        backgroundColor: '#ffffff',
        shadowColor: '#ff544f',
    },
    label: {
        color: '#ffffff',
        fontWeight: '400',
        textAlign: 'left',

        justifyContent: "flex-start",
        // textAlignVertical:"left",
        alignItems: "flex-start",
    },
});