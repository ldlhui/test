
import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Dimensions,
    DeviceEventEmitter
} from 'react-native';

import { connect } from 'react-redux'; // 引入connect函数
import { NavigationActions } from 'react-navigation';
import *as Actions from '../../action/counterAction';

import { bindActionCreators } from 'redux'
import { TabView, TabBar, SceneMap } from 'react-native-tab-view';

import AppStyles from "../../../styles/AppStyles";
import FirstRoute from "../../components/chinaTown";
import SecondRoute from "../../components/otherStore";


import { OrderQuery, DailySum,Update } from "../../api";
// import firebase from 'react-native-firebase';
// import type { Notification, NotificationOpen, RemoteMessage } from 'react-native-firebase';

import MyTabBar from '../../unitl/MyTabBar';

const { width, height } = Dimensions.get('window');
const mapStatesToProps = state => ({
    count: state.counter.count
});

const mapDispatchToProps = dispatch => ({
    actions: bindActionCreators(Actions, dispatch)
});

class MainPage extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            index: 0,
            routes: [
                { key: 'first', title: 'China Town' },
                { key: 'second', title: 'EasyDish' },
            ],
            titleNumber:[0,0]
        };
    }

    // static navigationOptions = {    
    //     header: null
    // };

    _renderTabBar = props => (
        <TabBar {...props} style={styles.tabbar}
        titleStyle={AppStyles.header}
        titleContent={"New Orders"}
        titleNumber={props.titleNumber}
        NumberStyle={AppStyles.NumberStyle}
        scrollEnabled={false}
        onTabPress={(data)=>{this.setState({index:data})}}
        labelStyle={styles.label} />
    );

    // logout() {
    //     this.props.navigation.dispatch(resetAction)
    // }


    // getData() {
    //     global.storage.load({
    //         key: 'location'
    //     }).then(locations => {
                
    //             OrderQuery({status:'new',type: 'current',
    //                 shopModel:{shopId:'2321321jb'},
    //                 driverModel:{driverLat:locations.latitude,
    //                     driverLon:locations.longitude,
    //                     driverName: 'Jim',
    //                     driverId: '0001vb'
    //                 }
    //             }).then((data) => {
    //                 OrderQuery({status:'new',type: 'others',
    //                 shopModel:{shopId:'2321321jb'},
    //                 driverModel:{driverLat:locations.latitude,
    //                     driverLon:locations.longitude,
    //                     driverName: 'Jim',
    //                     driverId: '0001vb'
    //                 }
    //                 }).then((otherData) => {
        
    //                     DeviceEventEmitter.emit('msg', {
    //                         homePageNumber:  [data.data.length,otherData.data.length]
    //                     });
        
    //                     this.setState({
    //                         titleNumber: [data.data.length,otherData.data.length]
    //                     })
    //                 });
    //             });

    //             // OrderQuery({status:'accepted',type: 'current',
    //             // shopModel:{shopId:'2321321jb'},
    //             // driverModel:{driverLat:location.coords.latitude,
    //             //     driverLon:location.coords.longitude,
    //             //     driverName: 'Jim',
    //             //     driverId: '0001vb'
    //             // }
    //             // }).then((data) => {
    //             //     OrderQuery({
    //             //         status:'accepted',type: 'others',
    //             //         shopModel:{shopId:'2321321jb'},
    //             //         driverModel:{driverLat:location.coords.latitude,
    //             //         driverLon:location.coords.longitude,
    //             //         driverName: 'Jim',
    //             //         driverId: '0001vb'
    //             //     }
    //             //     }).then((otherData) => {
        
    //             //         DeviceEventEmitter.emit('msg', {
    //             //             driverTitleNumber:  [data.data.length,otherData.data.length]
    //             //         });
    //             //         this.setState({
    //             //             titleNumber: [data.data.length,otherData.data.length]
    //             //         })
    //             //     });
    //             // });

    //         }
    //         , error => {

    //         }
    //     );
        // OrderQuery({
        //     "content-type": "application/json",
        //     authorization: token,
        //     driverLat: 0,
        //     driverLon: 0,
        //     driverName: "Jim",
        //     driverId: "0001vb",
        //     shopId: "001bbb",
        //     status: "new",
        //     type: "current"
        // }).then((data) => {
        //     // alert(JSON.stringify(data))
        //     OrderQuery({
        //         "content-type": "application/json",
        //         authorization: token,
        //         driverLat: 0,
        //         driverLon: 0,
        //         driverName: "Jim",
        //         driverId: "0001vb",
        //         shopId: "001bbb",
        //         status: "new",
        //         type: "current"
        //     }).then((otherData) => {

        //         DeviceEventEmitter.emit('msg', {
        //             homePageNumber:  [data.data.length,otherData.data.length]
        //         });

        //     });
        // });
    // }


    async componentDidMount() {
        DeviceEventEmitter.addListener('msg', (title) => {
            if (title) {
                if (title.homePageNumber)
                    this.setState({
                        titleNumber: title.homePageNumber
                    });
            }
        });
        global.storage.save({
            key: 'ShiftOhters',
            data: false,
            expires: null
        });

        // this.props.actions.increment()

        // const navigateAction = NavigationActions.navigate({
        //     routeName: 'Home',
        //     index: 112,
        //     params: { homeCount: 12, driverCount: 12 },
          
        //     action: NavigationActions.navigate({ routeName: 'Home' }),
        // });

        // this.props.navigation.dispatch(navigateAction);

        // this.getData();
    }


    render() {
        return (<View style={{width:width,height:height}}>
            <TabView
                navigationState={this.state}
                renderScene={SceneMap({
                    first: FirstRoute,
                    second: SecondRoute,
                })}
                titleNumber={this.state.titleNumber}
                navigation={this.props.navigation}
                renderTabBar={this._renderTabBar}
                onIndexChange={index => this.setState({ index })}
                initialLayout={{ width: Dimensions.get('window').width,height:20}}
            />
            <MyTabBar
                    tabs={
                        ["Home", "driver", "map", "delivered", "user"]
                    }

                    titleNumber={this.state.titleNumber}
                    deliveredNumber={this.state.deliveredNumber}
                    driverTitleNumber={this.state.driverTitleNumber}

                    activeTab={this.state.activeTab}
                    goToPage={(data) => {
                        this.setState({
                            activeTab: data
                        })
                        // alert(JSON.stringify(this.props.history));
                        // this.props.navigation.push(data);
                        // return <Redirect
                        //     to={{
                        //         pathname: "/"+data,
                        //         // state: { from: props.location }
                        //     }}
                        // />
                    }}
                >
                </MyTabBar>
        </View>)
    }
}

export default MainPage;

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    tabbar: {
        backgroundColor: '#ffffff',
        shadowColor: '#ff544f',
    },
    label: {
        color: '#ffffff',
        fontWeight: '400',
        textAlign:'left',
        
        justifyContent:"flex-start",
        alignItems:"flex-start",
    },
});