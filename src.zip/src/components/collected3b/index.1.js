
import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Dimensions,
    Button,
    TouchableHighlight,
    WebView,
    Animated,
    TouchableNativeFeedback,
    Linking,
    // DeviceEventEmitter,
    ScrollView,
    Alert
} from 'react-native';

const { width, height } = Dimensions.get('window');
import AppStyles from "./style";
// import { Text, View} from 'react-native';
// import PopUp from "../common/popup";
// import {
//     StackNavigator,
//     TabNavigator
// } from 'react-navigation';

import Svg from "../../../icons/icons";

import { OrderQuery, DailySum, Update } from "../../api";

import LineBtn from "../lineBtn";

/**
 * @app
 */
class ChinaTown extends React.Component {

    /**
     * @constructor
     * @param props
     */
    constructor(props) {
        super(props);
        this.token = null;


        let initialVisibility = 1;

        const initialOffset = {
            x: this._getScrollAmount(1, 1),
            y: 0,
        }

        this.state = {
            index: 0,
            orderSize: 1,
            notif: null,
            payload: null,
            newOtherOrderData: null,
            showOrders: true,
            windex:1,
            visibility: new Animated.Value(initialVisibility),
            scrollAmount: new Animated.Value(0),
            initialOffset
        }
        this.oData = null;
    }

    _getScrollAmount = (i) => {
        const tabWidth = width;
        const centerDistance = tabWidth * (i + 1 / 2);
        const scrollAmount = centerDistance - width / 2;

        return this._normalizeScrollValue(scrollAmount);
    };

    _normalizeScrollValue = (value, size) => {
        const tabWidth = width;
        const tabBarWidth = Math.max(
            tabWidth * size,
            width
        );
        const maxDistance = tabBarWidth - width;

        return Math.max(Math.min(value, maxDistance), 0);
    };

    showDailog(item, _this) {
        let info = "";
        item.driverPaidStatus ? "Did you pay sotre. €"+item.driverPaid:"Did the store pay you. €"+item.storePaid
        Alert.alert('','Did you collect all delivery items? \n  ',
        [
            {text:"Yes", onPress:this.updateData(item, _this,"Yes")},
            // {text:"No", onPress:this.updateData(item, _this,"No")},
            {text:"No", onPress:()=>{

            }},
        ]
        );
    }

    updateData(item, _this, type) {
        Update({
            orderId: item.orderId,
            updateStatus: "delivered",
            status: item.status,
            type: 'current',
            driverModel: {
                driverId: "d001"
            }
        }).then((data) => {
            // DeviceEventEmitter.emit('DelNumberEmt', {
            //     data: true
            // });
            _this.getData()
        });
    }

    getData(data) {
        global.storage.load({
            key: 'location'
        }).then(locations => {
                OrderQuery({
                    status: "collected",
                    shopModel: { shopId: "001bbb" },
                    driverModel: {
                        latitude: locations.latitude,
                        longitude: locations.longitude,
                        name: "Jim",
                        driverId: "d001"
                    }
                }).then((data) => {
                    this.oData = data.data;
                    this.setState({
                        newOtherOrderData: data,
                        orderSize: data.data.length
                    })
                });
            }
            , error => {

            });
        this.setState({
            showOrders: true
        })
    }
    onPressLearnMore() {

    }

    _rederOtherData = (item, index,length) => {
        let _this = this;

        let windex = (this.state.windex-1)*5;
        return (<ScrollView style={[AppStyles.mainTabContainer, { width: width, height: height * .7 }]}>
                
                <View
                    style={{
                        flex: 1,
                        flexDirection: 'column',
                        height: height - 300,
                    }}
                >
                    <View style={{
                        height: height - 300,
                        flex: 1,
                        flexDirection: 'column'
                    }}>
                        <View style={{ height: 100 }}>
                            <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'space-between', width: width / 2 - 4 }}>
                                <View style={[AppStyles.middleButtonLeft, { width: width - 8 }, AppStyles.middleButton,
                                { height: 100, backgroundColor: '#f0695a',
                                    borderRightWidth: 0,
                                    borderLeftWidth: 0,
                                    marginLeft:3,
                                    marginRight:3,                            
                                    // borderRightColor: "#ffffff",
                                    // borderLeftColor: "#ffffff"
                                }]}>
                                    <View style={{
                                        borderWidth: 2,
                                        borderColor: "#f0695a", height: (width / 2 - 8) * 0.42, paddingLeft: 5, fontWeight: "bold"
                                    }}>
                                        <View style={{ flexDirection: 'row', height: 25 }}>
                                            <Text style={styles.iconStyle}>&#xe606;</Text>
                                            <Text style={[styles.lineFont, { color: "#ffffff" }]}> {item.shopModel.name} </Text>
                                        </View>
                                        <View style={{ flexDirection: 'row', height: 25 }}>
                                            <Text style={styles.iconStyle}>&#xe609;</Text>
                                            <Text style={[styles.lineFont, { color: "#ffffff" }]}> {item.shopModel.phone} </Text>
                                        </View>
                                        <View style={{ flexDirection: 'row', minHeight: 25 }}>
                                            <Text style={styles.iconStyle}>&#xe607;</Text>
                                            <Text style={[styles.lineFont, { color: "#ffffff", width: width * .8 - 30 }]}>
                                                {item.shopModel.address}
                                            </Text>
                                        </View>
                                    </View>
                                </View>
                                <View style={[AppStyles.middleButtonRight, { width: width * .2 }, AppStyles.middleButton,
                                { height: 100, backgroundColor: '#f0695a', borderRightColor: "#f0695a" }]}>
                                    <TouchableHighlight
                                        onPress={() => { Linking.openURL(`tel:` + item.shopModel.phone) }}
                                    >
                                        <View style={{
                                            flexDirection: 'row', justifyContent: "flex-end", borderWidth: 2,
                                            borderColor: "#f0695a", height: (width / 2 - 8) * 0.42,
                                            paddingLeft: 5, fontWeight: "bold"
                                        }}>
                                            <Text style={[{
                                                borderRadius: 45,
                                                width: 45,
                                                height: 45,
                                                fontSize: 45,
                                                padding: 0,
                                                color: '#ffffff',
                                                fontFamily: 'iconfont'
                                            }]}>&#xe60a;</Text>
                                        </View>
                                    </TouchableHighlight>
                                </View>
                            </View>
                        </View>


                        <View style={[AppStyles.middleButton, { marginTop: 5 }]}>
                            <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'space-between', width: width }}>
                                <View style={[AppStyles.middleButtonLeft, { width: width / 2 - 8 },
                                AppStyles.middleButton, { height: (width / 2 - 8) * 0.42, borderBottomColor: "#f7f7f7", borderBottomWidth: 2 }]}>
                                    {/* <TouchableHighlight
                                        onPress={() => { this.props.navigation.push('Chat') }}
                                    > */}
                                        <View style={{
                                            flexDirection: 'row', justifyContent: "space-between",
                                            height: (width / 2 - 8) * 0.42, paddingLeft: 5, fontWeight: "bold"
                                        }}>
                                            <View>
                                                <Text style={styles.activeFont}>
                                                    {item.orderId}
                                                </Text>
                                            </View>
                                        </View>
                                    {/* </TouchableHighlight> */}
                                </View>
                                {
                                    item.driverPaidStatus ? (<View style={[AppStyles.middleButtonRight,
                                    { width: width / 2 - 8 }, AppStyles.middleButton,
                                    {
                                        height: (width / 2 - 8) * 0.42,
                                        backgroundColor: "#f0695a",
                                        paddingLeft: 15,
                                        paddingTop: 5
                                    }]}>
                                        <View style={{
                                            flexDirection: 'row', justifyContent: "space-between",
                                            height: (width / 2 - 8) * 0.42, paddingLeft: 5, fontWeight: "bold"
                                        }}>
                                            <View>
                                                <Text style={[styles.activeFont, { color: "#ffffff" }]}>Due to Store</Text>
                                                <Text style={[styles.activeFont, { color: "#ffffff" }]}>€{item.driverPaid}</Text>
                                            </View>
                                        </View>
                                    </View>) : (<View style={[AppStyles.middleButtonRight,
                                    { width: width / 2 - 8 }, AppStyles.middleButton,
                                    {
                                        height: (width / 2 - 8) * 0.42,
                                        backgroundColor: "#62a55d",
                                        paddingLeft: 15,
                                        paddingTop: 5
                                    }]}>
                                        <View style={{
                                            flexDirection: 'row', justifyContent: "space-between",
                                            height: (width / 2 - 8) * 0.42, paddingLeft: 5, fontWeight: "bold"
                                        }}>
                                            <View>
                                                <Text style={[styles.activeFont, { color: "#ffffff" }]}>Due to You</Text>
                                                <Text style={[styles.activeFont, { color: "#ffffff" }]}>€{item.storePaid}</Text>
                                            </View>
                                        </View>
                                    </View>)
                                }
                            </View>
                        </View>


                        <View style={{ height: 1 }}>
                        </View>


                        <View style={AppStyles.middleButton}>
                            <View style={{
                                flex: 1, flexDirection: 'row', justifyContent: 'space-between', width: width
                            }}>
                                <View style={[AppStyles.middleButtonLeft, { width: width / 2 - 8 }, AppStyles.middleButton,
                                { height: (width / 2 - 8) * 0.45 }]}>
                                    <TouchableHighlight
                                        // onPress={() => { this.props.navigation.push('Chat') }}
                                        onPress={() => {
                                            var path = {
                                                pathname:'/map',
                                                state:{
                                                    destination: {
                                                        latitude: item.latitude,
                                                        longitude: item.longitude
                                                    },
                                                    data:item
                                                },
                                                history: this.props.history
                                            }
                                            this.props.history.push(path);

                                            // this.props.navigation.navigate('map', {
                                            //     destination: {
                                            //         latitude: item.latitude,
                                            //         longitude: item.longitude
                                            //     },
                                            //     data:item
                                            // })

                                        }}
                                    >
                                        <View style={{
                                            flexDirection: 'row',
                                            height: (width / 2 - 8) * 0.42, paddingLeft: 5, fontWeight: "bold"
                                        }}>

                                            <View style={[{
                                                backgroundColor: "#ff544f",
                                                width: 45,
                                                height: 45,
                                                margin: 5,
                                                fontSize: 45
                                            }, styles.center]}>
                                                <Text style={[styles.iconStyle, { fontSize: 32, color: "#ffffff" }]}>&#xe602;</Text>
                                            </View>
                                            <View>
                                                <Text style={[styles.activeFont, {
                                                    color: "#ff544f",
                                                    fontSize: 18, paddingTop: 12
                                                }]}>Direction</Text>
                                            </View>
                                        </View>
                                    </TouchableHighlight>
                                </View>
                                <View style={[AppStyles.middleButtonRight, { width: width / 2 - 8 }, AppStyles.middleButton,
                                { height: (width / 2 - 8) * 0.42 }]}>
                                    {/* {item.shopModel.phone} */}
                                    <TouchableHighlight
                                        onPress={() => { Linking.openURL(`tel:` + item.shopModel.phone) }}
                                    // onPress={() => { this.props.navigation.push('Chat') }}
                                    >
                                        <View style={{
                                            flexDirection: 'row',
                                            height: (width / 2 - 8) * 0.42, paddingTop: 5, fontWeight: "bold"
                                        }}>
                                            <TouchableHighlight
                                                onPress={() => { Linking.openURL(`tel:` + item.phone) }}
                                            // style={{ backgroundColor: "#f0695a" }}
                                            >
                                                <View style={{ flexDirection: 'row' }}>
                                                    <Text style={[{
                                                        // borderColor: "#f0695a",
                                                        // borderWidth: 1,
                                                        fontSize: 45,
                                                        width: 45,
                                                        height: 45,
                                                        padding: 0,
                                                        // backgroundColor: "#f0695a",
                                                        color: '#f0695a',
                                                        fontFamily: 'iconfont'
                                                    }]}>&#xe608;</Text>

                                                    <Text style={[styles.activeFont, {
                                                        color: "#ff544f",
                                                        fontSize: 18, paddingTop: 12
                                                    }]}>
                                                        Call Customer
                                                </Text>
                                                </View>
                                            </TouchableHighlight>
                                        </View>
                                    </TouchableHighlight>
                                </View>
                            </View>
                        </View>

                        <View style={{ justifyContent: "center", flexDirection: 'row', marginTop: 5 }}>
                            <Text style={[styles.iconStyle, { color: "#ff544f" }]}>&#xe604;</Text>
                            <View style={{ paddingLeft: 5 }}>
                                <Text style={{ width: width * .85 }}>
                                    {item.address}
                                </Text>
                            </View>
                        </View>
                        <View style={{ width: width - 16, height: 5 }}></View>
                        <View style={{ width: width - 16, height: 2, backgroundColor: "#f7f7f7" }}></View>
                        <View style={{
                            flex: 1, flexDirection: 'row',
                            justifyContent: 'space-between',
                            width: width - 16, height: 36, paddingLeft: 15, paddingRight: 15
                        }}>
                            <View style={{ height: 36, paddingTop: 8 }}>
                                <Text style={{ fontSize: 20, fontWeight: "bold", color: "#000000" }}>{item.time} Mins ({item.distance} KM)</Text>
                            </View>
                            {/* <View>
                            <Text style={{ fontSize: 36, fontWeight: "bold", color: "#ff544f" }}>€{item.deliverFee}</Text>
                        </View> */}
                        </View>
                    </View>
                </View>
                {/* <View style={{
                    width: width - 16, margin: 8, flexDirection: 'row',
                    backgroundColor: "#739e5e",
                    borderRadius: 50
                }}
                    onPress={() => {//asd11
                        Update({
                            orderId:item.orderId,
                            updateStatus: "delivered",
                            driverPaidStatus: true,
                            storePaidStatus: true,
                            status: item.status,
                            driverModel: {
                                driverId: "d001"   
                            }
                        }).then((data) => {
                            this.showDailog(item, _this);
                        });
                    }}
                >
                    <Svg key={`key-1`} icon={"greenslider-arrow-144x144"}
                        fill="#000000"
                        style={{ width: 50, height: 50 }} />
                    <TouchableHighlight
                        onPress={() => {
                            Update({
                                orderId:item.orderId,
                                updateStatus: "delivered",
                                driverPaidStatus: true,
                                storePaidStatus: true,
                                status: item.status,
                                driverModel: {
                                    driverId: "d001"   
                                }
                            }).then((data) => {
                                this.showDailog(item, _this);
                            });
                        }}
                        style={{
                            width: width * .6,
                            flex: 0, height: 50,
                            alignItems: 'center',
                            justifyContent: 'center'
                        }}
                    >
                        <Text
                            style={{ fontSize: 38, fontWeight: "bold", color: "#FFFFFF" }}>Delivered</Text>
                    </TouchableHighlight>
                </View> */}

                <View style={{
                    flexDirection: 'row',
                    width:width,
                    justifyContent:"center"
                }}>
                        <LineBtn item={item} width={width*.7} title={"Delivered"} showDailog={(item)=>{
                            this.showDailog(item, _this);
                        }}>
                        </LineBtn>
                </View>
                <View
                    style={{
                        width: width - 16,
                        height: 50
                    }}
                >
                    <TouchableHighlight
                        onPress={() => {
                            Update({
                                orderId: item.orderId,
                                updateStatus: "new",
                                status: item.status,
                                driverModel: {
                                    driverId: "d001"   
                                }
                            }).then((data) => {
                                this.getData()
                            });
                        }}

                        style={{
                            width: width,
                            flex: 0, height: 25,
                            alignItems: 'center',
                            justifyContent: 'center'
                        }}
                    >
                        <View
                            style={{ flexDirection: 'row' }}
                        >
                            <Text
                                style={{
                                    fontSize: 20, fontWeight: "bold", color: "#000000",
                                    width: 140,
                                    textAlign: "center"
                                }}>Delivery Failed</Text>
                            <Text style={{ fontSize: 15, fontFamily: 'iconfont', paddingTop: 5 }}>&#xe625;</Text>
                        </View>
                    </TouchableHighlight>
                    <View style={{ flexDirection: 'row', width: width, justifyContent: "center" }}>

                        <Text style={{
                            color: "#f0695a",
                            fontFamily: 'iconfont'
                        }}>
                            &#xe6bc;
                        </Text>
                        <Text style={{
                            width: 80,
                            justifyContent: "center",
                            textAlign: "center"
                        }}>
                            {windex+index + 1} to {length}
                        </Text>
                        <Text style={{
                            color: "#f0695a",
                            fontFamily: 'iconfont'
                        }}>
                            &#xe62d;
                        </Text>

                    </View>
                </View>
            </ScrollView>)
    }

    async componentDidMount() {
        this.getData();
    }


    handleScroll(event) {
        // alert(JSON.stringify(event.nativeEvent));
    }

    backScoll() {
        let mainData = this.oData;

        let windex = (this.state.windex-1)*5;

        let data =  this.oData.length/5;
        if(data<1) return false;
        let dataL = parseInt(data);
        if(data>dataL) dataL = dataL+1;

        let sw = this.state.windex-1;
        if(sw==0) return false;
        if(sw<dataL) {
            let cData = [mainData[windex-5],mainData[windex-4],mainData[windex-3],mainData[windex-2],mainData[windex-1]];

            this.setState({
                newOtherOrderData:{
                    data: cData
                },
                windex: this.state.windex-1
            })
        }

    }

    goScoll() {
        // let mainData = this.state.newOtherOrderData.data;
        let mainData = this.oData;

        let windex = (this.state.windex+1)*5;

        let data = this.oData.length/5;

        // let data = this.state.newOtherOrderData.data.length/5;
        let dataL = parseInt(data);
        if(data>dataL) dataL = dataL+1;

        let sw = this.state.windex+1;

        if(sw<dataL) {
            let cData = [];
            if(data>dataL) {
                // let Data1 = null,Data2= null,Data3= null,Data4= null,Data5= null

                cData = [];
                if(mainData[windex+1]) cData[0]=mainData[windex+1];

                if(mainData[windex+2]) cData[1]=mainData[windex+2];

                if(mainData[windex+3]) cData[2]=mainData[windex+3];

                if(mainData[windex+4]) cData[3]=mainData[windex+4];

                if(mainData[windex+5]) cData[4]=mainData[windex+5];



            } else {
                cData = [mainData[windex+1],mainData[windex+2],mainData[windex+3],mainData[windex+4],mainData[windex+5]];

            }

            this.setState({
                newOtherOrderData:{
                    data: cData
                },
                windex: this.state.windex+1
            })
        }
    }

    /**
     * @render
     * @returns {*}
     */
    render() {

        let initialOffset = {
            // x: this._getScrollAmount(this.state.index, this.state.orderSize),
            x: 0,
            y: 0,
        }
        let max = width*4;
        // const length = JSON.parse(JSON.stringify(this.props.fucn.ddd.rightData));
        
        return (<View style={{width:width,height:height-170}}>
                {/* <Text>
                    {width}
                </Text> */}
                {
                    // this.state.showOrders ? (
                        this.state.newOtherOrderData && this.state.newOtherOrderData.data ?
                            <View style={styles.scroll}>
                                {/* <Animated.ScrollView */}
                                <ScrollView
                                    horizontal
                                    keyboardShouldPersistTaps="handled"
                                    bounces={true}
                                    alwaysBounceHorizontal={true}
                                    scrollsToTop={true}
                                    showsHorizontalScrollIndicator={false}
                                    automaticallyAdjustContentInsets={false}
                                    // canCancelContentTouches={true}
                                    // overScrollMode="never"
                                    scrollTo={{x:0,y:0}}
                                    pagingEnabled={true}
                                    contentOffset={initialOffset}
                                    onScroll={this.handleScroll.bind(this)}
                                    // refreshControl={data=>alert(data)}
                                    removeClippedSubviews
                                    alwaysBounce={true}
                                    bouncesZoom={true}
                                    ref='_scrollView'
                                    onScrollEndDrag={(event) => {
                                        // alert(JSON.stringify(event.nativeEvent.contentOffset.x));
                                        
                                        if(event.nativeEvent.contentOffset.x==0)this.backScoll();

                                        if(event.nativeEvent.contentOffset.x==max){
                                            this.refs._scrollView.scrollTo(0,0,false);
                                            this.goScoll();
                                        }
                                    }}
                                >
                                    {this.state.newOtherOrderData.data.map((data, index) => 
                                       index < 5&&data!=null ? this._rederOtherData(data, index,this.oData.length):null)}
                                </ScrollView>
                                {/* </Animated.ScrollView> */}
                            </View> : null
                    // ) : null
                }
            </View>
        )
    }
}
const styles = StyleSheet.create({
    defWidth: {
        width: width / 2 - 8
    },
    defHeight: {
        width: (width / 2 - 8) * 0.42
    },
    iconStyle: {
        color: '#ffffff',
        fontFamily: 'iconfont',
        fontSize: 20
    },
    iconStyleSM: {
        color: '#ffffff',
        fontFamily: 'iconfont',
        fontSize: 16
    },
    activeFont: {
        fontSize: 24,
        fontWeight: "bold",
        color: "#000000"
    },

    lineFont: {
        fontSize: 16,
        color: "#000000",
        paddingLeft: 5
    },
    center: {

        textAlign: 'center',
        alignItems: 'center',
        justifyContent: 'center',
        textAlignVertical: 'center'
    }
})
export default ChinaTown;