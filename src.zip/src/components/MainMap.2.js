
/**
 * @imports
 */
import { PermissionsAndroid, NativeModules } from 'react-native';
import React, { Component } from 'react';
import { ScrollView, View, Text, TextInput, TouchableOpacity, Alert, StyleSheet, Dimensions, Button, 
    TouchableHighlight,Linking,
    DeviceEventEmitter } from 'react-native';
import MapView, { PROVIDER_GOOGLE } from 'react-native-maps';
import MapViewNavigation, {
    NavigationModes, TravelModeBox, TravelIcons,
    TravelModes, DirectionsListView, ManeuverView, DurationDistanceView
}
    from 'react-native-maps-navigation';
import OptionGroup from 'react-native-optiongroup';
import Styles, { AppColors, AppFonts } from '../../styles/AppStyles';
import MapStyles from '../../styles/MapStyles';
// import Geocoder from 'react-native-geocoder';
import MapViewDirections from 'react-native-maps-directions';
import { StackNavigator, TabBarBottom, TabNavigator, createStackNavigator, createAppContainer } from "react-navigation";


import { NativeRouter, Route, Link } from "react-router-native";
import Svg from "../../icons/icons";

import AppStyles from "./uncollected";

import { OrderQuery, DailySum,Update } from "../api";

import MyTabBar from '../unitl/MyTabBar';

import LineBtn from "../components/lineBtn";

const { width, height } = Dimensions.get('window');
var Geolocation = require('Geolocation');
const ASPECT_RATIO = width / height;
const LATITUDE_DELTA = 0.003;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;


const GEOLOCATION_OPTIONS = { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 };
/**
 * Settings
 * @type {string}
 */

/**
 * You need to fill in a Google API Key that enables the Direction API.
 */
const GOOGLE_API_KEY = 'AIzaSyDb2jB0BGD_4ds0O-HSOk6afQUrwMcbDeA';

/**
 * Set to true to use the controls methods instead of props
 * @type {boolean}
 */
const USE_METHODS = false;

const defaultProps = {
    enableHack: false,
    geolocationOptions: GEOLOCATION_OPTIONS,
};

/**
 * @app
 */
export default class MapApp extends Component {

    // static navigationOptions = {
    //     title: null, header: null,
    //     tabBarLabel: '主页',
    //     tabBarIcon: ({ focused, tintColor }) => (
    //         <Image
    //             style={{ width: 26, height: 26, tintColor: tintColor }}
    //         />
    //     )
    // };

    /**
     * @constructor
     * @param props
     */
    constructor(props) {
        super(props);

        this.props = props;

        this.timer = null;
        this.count = 1;
        this.lnlg = "";
        this.state = {
            origin: { latitude: 0, longitude: 0 },
            destination: { latitude: 35.785094, longitude: 139.663175 },
            navigationMode: NavigationModes.IDLE,
            travelMode: TravelModes.DRIVING,
            isFlipped: false,
            isNavigation: false,
            route: false,
            step: false,
            titleNumber: [0, 0],
            deliveredNumber: [0, 0],
            driverTitleNumber: [0, 0]
        }


        this.mounted = false;

        PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.ACCESS_COARSE_LOCATION,
            {
                'title': 'Cool Photo App Camera Permission',
                'message': 'Cool Photo App needs access to your camera ' +
                    'so you can take awesome pictures.'
            }
        )
    }

    static navigationOptions = {    
        header: null
    };

    getData(data) {
        global.storage.load({
            key: 'location'
        }).then(locations => {
                // alert(JSON.stringify(location.accuracy));
                OrderQuery({
                    status: data.status,
                    type: "others",
                    shopModel: { shopId: "001bbb" },
                    driverModel: {
                        latitude: locations.latitude,
                        longitude: locations.longitude,
                        name: "Jim",
                        driverId: "d001",
                        allowDistance:"20"
                    }
                }).then((data) => {
                    OrderQuery({
                        status: 'new', type: 'current',
                        shopModel: { shopId: '2321321jb' },
                        driverModel: {
                            latitude: locations.latitude,
                            longitude: locations.longitude,
                            name: 'Jim',
                            driverId: 'd001'
                        }
                    }).then((otherData) => {
                        // DeviceEventEmitter.emit('msg', {
                        //     homePageNumber:  [otherData.data.length,data.data.length]
                        // });
                    })

                    this.setState({
                        newOtherOrderData: data,
                        orderSize: data.data.length,
                        accuracy:accuracy
                    })
                    global.storage.save({
                        key: 'showOrders',
                        data: true,
                        expires: null
                    });
                });
            }
            , error => {

            });
        this.setState({
            showOrders: true
        })
    }
    /**
     * goDisplayRoute
     * @void
     */
    goDisplayRoute() {
        if (!this.validateRoute()) return;

        // There are two ways to display a route - either through the method
        // displayRoute or by setting the props.
        // The difference is that you get instant feedback when using methods vs props.

        if (USE_METHODS) {
            this.refNavigation.displayRoute(
                this.state.origin,
                this.state.destination,
                {
                    mode: this.state.travelMode
                }
            ).then(route => {
                console.log(route);
            });

        } else {

            this.setState({
                navigationMode: NavigationModes.ROUTE,
            });
        }
    }
    /**
     * goNavigateRoute
     * @void
     */
    goNavigateRoute() {
        if (!this.validateRoute()) return;

        // There are two ways to navigate a route - either through the method
        // navigateRoute or by setting the props.
        // The difference is that you get instant feedback when using methods vs props.

        if (USE_METHODS) {
            this.refNavigation.navigateRoute(
                this.state.origin,
                this.state.destination,
                {
                    mode: this.state.travelMode
                }
            ).then(route => {
                this.setState({
                    isNavigation: true
                })
            });

        } else {
            this.setState({
                navigationMode: NavigationModes.NAVIGATION,
            });
        }
    }

    /**
     * validateRoute
     * @returns {boolean}
     */
    validateRoute() {
        if (this.state.destination.length >= 3) return true;

        Alert.alert('Address required', 'You need to enter an address first');

        return false;
    }

    getLocation() {
        // navigator.geolocation.getCurrentPosition(
        //     location => {
        //         var search = location.coords.latitude + "," +
        //             location.coords.longitude;
        //         // alert(search);
        //         // this.setState({ searchString: search }); 
        //         // var query = urlForQueryAndPage("centre_point", search, 1); 
        //         // this._executeQuery(query); 
        //     }
        //     , error => {
        //         // this.setState({ message: "There was a problem with obtaining your location: " + error }); 

        //     });

        // let data = NativeModules.ToastExample;
        NativeModules.ToastExample.show("asd", 0, (data) => {

            data = JSON.parse(data);
            // alert(JSON.stringify(data));
            this.setState({
                origin: {
                    latitude: data.latitude,
                    longitude: data.longitude,
                    Accuracy: data.Accuracy,
                }
            })
            this.count++;
        });
    }

    componentWillMount() {

        this.timer && clearTimeout(this.timer);
    }

    showDailog(item, _this,updateStatus) {
        // _this.setState({
        //     // isVisible: true,
        //     item: item
        // })

        let info = "";
        //  !item.orderPaidStatus ? "Did you pay sotre.  "+item.driverPaid:"";

        if (!item.orderPaidStatus) info = "Did you pay store €" + item.driverPaid;
        if (!item.orderPaidStatus) info = "Did the store pay you €" + item.storePaid;
        Alert.alert('', 'Did you collect all delivery items? \n ' + info,
            [
                {
                    text: "Yes", onPress: () => {
                        this.updateData(item, _this, updateStatus);
                    }
                },
                // {text:"No", onPress:this.updateData(item, _this,"No")},
                {
                    text: "No", onPress: () => {

                    }
                },
            ]
        );
        // setTimeout(function () { _this.setState({ isVisible: false }) }, 10000);this.confirm

    }


    updateData(item, _this, updateStatus) {
        Update({

            orderId: item.orderId,
            updateStatus: updateStatus,
            status: item.status,
            type: 'current',
            driverModel: {
                driverId: "d001"
            }
        }).then((data) => {
            // this.props.navigation.push
            this.props.navigation.goBack()
        });
    }


    componentDidMount() {
        let me = this;
        // me.getLocation();
        // global.storage.load({
        //     key: 'chinaT'
        // }).then(data => {
        //     this.setState({
        //         titleNumber: data
        //     })
        // })
        // global.storage.load({
        //     key: 'driverData'
        // }).then(data => {
        //     this.setState({
        //         driverTitleNumber: data
        //     })
        // })

    }

    // _toast(){
    //     NativeModules.ToastModule.show('toast', 
    //     NativeModules.ToastModule.SHORT,(success)=>{alert(success)},(error)=>{alert(error)})
    // }

    /**
     * @render
     * @returns {*}
     */
    render() {
        this.timer && clearTimeout(this.timer);
        this.lnlg += "\nload\n";
        this.timer = setTimeout(this.getLocation.bind(this), 3200);

        const params = this.props.location.state;
        const {data,pathname} = params;

        // const { params } = this.props.navigation.state;

        let updateStatus = "";
        if(data.status=="collected") updateStatus = "delivered";
        if(data.status=="accepted") updateStatus = "collected";
 
        return (
            <View style={[Styles.appContainer,{height,height}]}>
                {/* <Text>
                    {this.state.Accuracy}
                </Text> */}
                <View
                    style={{
                        width: width,
                        height: 40,
                        flexDirection: 'row' 
                    }}
                >
                 <TouchableHighlight 
                    onPress={() => {
                        this.props.history.goBack(); 
                    }}>
                    <View
                        style={{
                            flexDirection: 'row',
                            paddingTop:5
                        }}
                    >
                        <Text  onPress={()=>{
                                this.props.history.goBack(); 
                            }} 
                            style={{
                                marginLeft:5,
                                width:50,
                                textAlign:"center",
                                fontFamily: 'iconfont',
                                fontSize: 20, 
                                paddingTop:5, 
                            }} 
                        >
                            &#xe614;
                        </Text>
                        <Text
                            style={{
                                fontSize: 20,
                                fontWeight:"bold"
                            }}
                        >
                            Direction
                        </Text>
                    </View>
                 </TouchableHighlight>
                    
                </View>
                {/* <Text>
                    {JSON.stringify(params)}
                </Text> */}
                <View
                    style={{
                        width: width,
                        height: width,
                    }}
                >
                    <View style={{
                        width: width,
                        height: width,
                        // transform: [{rotate:'45deg'}]
                    }}>
                        {
                        this.state.origin.latitude != 0 ? (<MapView
                            style={{
                                width: width,
                                height: width,
                                flex: 1,
                                backgroundColor:"#000000"
                            }}

                            // showUserLocation={true}
                            pitchEnabled={true}
                            Camera={{
                                center: {
                                    latitude: this.state.origin.latitude,
                                    longitude: this.state.origin.longitude,
                                },
                                pitch: 38,
                                heading: 90,
                                altitude: 1000,
                                zoom: 20,
                            }}

                            initialCamera={{
                                center: {
                                    latitude: this.state.origin.latitude,
                                    longitude: this.state.origin.longitude,
                                },
                                pitch: 38,
                                heading: 90,
                                altitude: 1000,
                                zoom: 18,
                            }}

                            showsUserLocation={true}
                            loadingEnabled={true}
                            followsUserLocation={true}
                        >
                            {/* <MapView.Marker coordinate={this.state.origin} /> */}

                            <MapView.Marker
                                coordinate={params.destination}
                            />

                            {
                                this.state.destination.latitude != 0 && this.state.origin.latitude ? (<MapViewDirections
                                    origin={this.state.origin}
                                    region={this.state.origin}
                                    destination={params.destination}
                                    apikey={GOOGLE_API_KEY}

                                    showUserLocation={true}
                                    strokeWidth={6}
                                    strokeColor="blue"
                                />) : null
                            }
                        </MapView>) : null
                    }
                    </View>
                </View>
                
                { this.state.origin.latitude != 0 ? (
                <View
                    style={{
                        width: width- 7,
                        position:"relative"
                    }}
                >
                    <View style={[AppStyles.middleButtonRight, {
                            flexDirection: 'row',
                            // justifyContent: "flex-start"
                            // justifyContent: "space-between"
                            height:80
                        },
                        AppStyles.middleButton, {
                            width: width,
                            paddingLeft: 25
                        }
                    ]}
                    >
                        <View>
                            <Text style={styles.activeFont}>{data.orderId} </Text>
                            {/* <Text style={[styles.activeFont, { fontSize: 15 }]}>In {
                            ((new Date(item.pickUpStart)).getTime() - (new Date(item.pickUpEnd)).getTime()) / 60000
                        } Mins</Text> */}
                        </View>
                        <View style={[{
                            backgroundColor: "#a0a0a0", padding: 5,
                            width: 80
                        }, AppStyles.middleButton, styles.center]}>
                            <TouchableHighlight
                                onPress={() => { Linking.openURL(`tel:` + data.shopModel.phone) }}
                                style={{ backgroundColor: "#a0a0a0" }}
                            >
                                <Text style={[{
                                    borderRadius: 40,
                                    borderColor: "#a0a0a0",
                                    borderWidth: 1,
                                    width: 40,
                                    height: 40,
                                    fontSize: 45,
                                    padding: 0,
                                    backgroundColor: "#ffffff",
                                    color: '#a0a0a0',
                                    fontFamily: 'iconfont'
                                }]}>&#xe60a;</Text>
                            </TouchableHighlight>
                        </View>
                        <View style={[
                            { width: 150}, AppStyles.middleButton,
                            {
                                height: 80,
                                backgroundColor: data.driverPaidStatus ? "#f0695a":"#62a55d",
                                paddingLeft: 15,
                                paddingTop: 5,
                                // marginLeft: 35,
                                position:"absolute",
                                right:0
                            }]}>
                            {
                                data.driverPaidStatus ? (<View style={{
                                    flexDirection: 'row', justifyContent: "space-between",
                                    height: (width / 2 - 8) * 0.42, paddingLeft: 5, fontWeight: "bold"
                                }}>
                                    <View>
                                        <View>
                                            <Text style={[styles.activeFont, { color: "#ffffff" }]}>Due to Store</Text>
                                            <Text style={[styles.activeFont, { color: "#ffffff" }]}>€{data.driverPaid}</Text>
                                        </View>
                                    </View>
                                </View>) : (<View ststyle={{
                                    flexDirection: 'row', justifyContent: "space-between",
                                    height: (width / 2 - 8) * 0.42, paddingLeft: 5, fontWeight: "bold"
                                }}>
                                    <View>
                                        <View>
                                            <Text style={[styles.activeFont, { color: "#ffffff" }]}>Due to You</Text>
                                            <Text style={[styles.activeFont, { color: "#ffffff" }]}>€{data.storePaid.toFixed(2)}</Text>
                                        </View>
                                    </View>
                                </View>)
                            }
                        </View>
                    </View>
                    <View style={{ justifyContent: "center", flexDirection: 'row', marginTop: 15 }}>
                        <Text style={[styles.iconStyle, { color: "#ff544f" }]}>&#xe604;</Text>
                        <View style={{ paddingLeft: 5 }}>
                            <Text style={{ width: width * .85 }}>
                                {/* 138 SPRINGDALE ROAD DUBLIN 5 D05 K8Y6 */}
                                {data.address}
                            </Text>
                        </View>
                    </View>
                    <View style={{flexDirection: 'row'}}>

                    <View style={{
                        flexDirection: 'row',
                        width:width,
                        justifyContent:"center"
                    }}>
                            <LineBtn item={data} width={width*.7} title={updateStatus}  showDailog={(data)=>{
                                this.showDailog(data, _this,updateStatus);
                            }}>
                            </LineBtn>
                    </View>
                    {/* <View style={{
                            marginTop: 10, width: width * .5, margin: 8, flexDirection: 'row',
                            backgroundColor: "#739e5e",
                            borderRadius: 50,
                            height: 50,
                            justifyContent:"flex-start",
                            position:"relative"
                        }}
                    >
                        <Svg key={`key-1`} icon={"greenslider-arrow-144x144"}
                            fill="#000000"
                            style={{ width: 50, height: 50 }} />
                        <TouchableHighlight
                            onPress={() => {
                                Update({

                                    orderId: data.orderId,
                                    updateStatus: updateStatus,
                                    status: data.status,
                                    type: 'current',
                                    driverModel: {
                                        driverId: "d001"
                                    }
                                }).then((data) => {
                                    // this.props.navigation.push
                                    this.props.navigation.goBack()
                                });
                            }}
                            underlayColor = '#739e5e'
                            style={{
                                width: width * .35,
                                flex: 0, height: 50,
                                alignItems: 'center',
                                justifyContent: "flex-start",
                                padding:10,
                                paddingTop:6,
                                borderRadius: 50
                            }}
                        >
                            <Text
                                style={{ 
                                    width: width * .5,
                                    fontSize: 25,
                                    fontWeight: "bold",
                                    color: "#FFFFFF",
                                    textAlign:"center"
                                }}>{updateStatus}</Text>
                        </TouchableHighlight>
                    </View> */}
                    <View style={{ paddingLeft: 20 }}>
                        <TouchableHighlight
                            onPress={() => {
                                // alert("123");
                                var path = {
                                    pathname:'/orderList',
                                    state: {
                                        updateStatus: updateStatus
                                    }
                                }
                                this.props.history.push(path);
                            }}
                        >
                            <View style={{ backgroundColor: "#f5f5f5",
                                height:50,
                                padding: 15, paddingLeft: 10, paddingRight: 10 }}>
                                    <Text 
                                    style={{
                                        fontSize: 16,
                                        fontWeight: "bold",
                                        color: "#000000"
                                    }}>Order List</Text>
                            </View>
                        </TouchableHighlight>
                    </View>

                    </View>
                </View>):null}
                {/* <View style={{
                    position:"absolute",
                    bottom:10
                }}>
                    <MyTabBar
                        tabs={
                            ["Home", "driver", "map", "delivered", "user"]
                        }
                        {...this.props}
                        titleNumber={this.state.titleNumber}
                        deliveredNumber={this.state.deliveredNumber}
                        driverTitleNumber={this.state.driverTitleNumber}

                        activeTab={"driver"}
                        goToPage={(data) => {
                            this.setState({
                                activeTab: data
                            })
                            if(data != "driver") this.props.history.push('/' + data);
                        }}
                    >
                    </MyTabBar>
                </View> */}
            </View>
        )
    }
}


const styles = StyleSheet.create({
    defWidth: {
        width: width / 2 - 8
    },
    defHeight: {
        width: (width / 2 - 8) * 0.42
    },
    iconStyle: {
        color: '#ffffff',
        fontFamily: 'iconfont',
        fontSize: 20
    },
    iconStyleSM: {
        color: '#ffffff',
        fontFamily: 'iconfont',
        fontSize: 16
    },
    activeFont: {
        fontSize: 24,
        fontWeight: "bold",
        color: "#000000"
    },

    lineFont: {
        fontSize: 16,
        color: "#000000",
        paddingLeft: 5
    },
    center: {

        textAlign: 'center',
        alignItems: 'center',
        justifyContent: 'center',
        textAlignVertical: 'center'
    }
})