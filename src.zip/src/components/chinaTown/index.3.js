
import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    Dimensions,
    TouchableHighlight,
    Animated,
    ScrollView,
    TouchableNativeFeedback,
    Linking,
    Alert,
    DeviceEventEmitter,
    InteractionManager,
    NativeModules,
    PanResponder
} from 'react-native';

const { width, height } = Dimensions.get('window');
import AppStyles from "./style";

import Svg from "../../../icons/icons";

import { OrderQuery, Update, startShift } from "../../api";

import LineBtn from "../lineBtn";

/**
 * @app
 */
class ChinaTown extends React.Component {

    /**
     * @constructor
     * @param props
     */
    constructor(props) {
        super(props);

        this.token = null;


        let initialVisibility = 1;

        const initialOffset = {
            x: this._getScrollAmount(1, 1),
            y: 0,
        }

        this.listingData = false;
        this.count = 1;
        this.Vdata = 0;
        this.state = {
            index: 0,
            viewIndex: 0,
            orderSize: 1,
            notif: null,
            payload: null,
            newOrderData: null,
            showOrders: false,
            windex: 1,
            visibility: new Animated.Value(initialVisibility),
            scrollAmount: new Animated.Value(0),
            initialOffset,
            isVisible: false,
            item: null,
            listingData: null,
            loadingData: "",
            s: "",
            e: "",
            sid:0,
            leftData:true,
            back: false
        }
        this.oData = null;
    }

    _getScrollAmount = (i) => {
        const tabWidth = width;
        const centerDistance = tabWidth * (i + 1 / 2);
        const scrollAmount = centerDistance - width / 2;

        return this._normalizeScrollValue(scrollAmount);
    };

    _normalizeScrollValue = (value, size) => {
        const tabWidth = width;
        const tabBarWidth = Math.max(
            tabWidth * size,
            width
        );
        const maxDistance = tabBarWidth - width;

        return Math.max(Math.min(value, maxDistance), 0);
    };


    componentWillMount() {

    }

    startShift() {
        var d = new Date();
        global.showOrders = true;
        global.storage.save({
            key: 'showOrders',
            data: true,
            expires: null
        });
        global.storage.save({
            key: 'showOrdersTime',
            data: d.getTime(),
            expires: null
        });
        startShift({
            status: "onCurrent",
            driverId: "d001"
        }).then((otherData) => {

        })

        this.getData();
    }
    async getData() {
        let s = new Date().getTime();
        let e = 0;
        global.storage.load({
            key: 'location'
        }).then(locations => {
            OrderQuery({
                status: 'new', type: 'current',
                shopModel: { shopId: '2321321jb' },
                driverModel: {
                    latitude: locations.latitude,
                    longitude: locations.longitude,
                    name: 'Jim',
                    driverId: "d001"
                }
            }).then((data) => {

                this.oData = data.data;
                e = new Date().getTime();
                this.setState({
                    s: s,
                    e: e
                })

                global.storage.load({
                    key: 'ShiftOhters'
                }).then(ret => {
                    // console.log(ret.userid);
                    if (ret) {

                        OrderQuery({
                            status: 'new', type: 'others',
                            shopModel: { shopId: '2321321jb' },
                            driverModel: {
                                latitude: locations.latitude,
                                longitude: locations.longitude,
                                name: 'Jim',
                                driverId: "d001"
                            }
                        }).then((otherData) => {
                            // alert(JSON.stringify(this.props));
                            // this.props.fucn.asd([data.data.length, otherData.data.length]);
                            // DeviceEventEmitter.emit('msg', {
                            //     deliveredNumber:  [data.data.length,otherData.data.length]
                            // });

                            this.props.onTitleNumber(data.data.length);
                            this.props.onRightNumber(otherData.data.length);
                            // DeviceEventEmitter.emit('msg', {
                            //     homePageNumber: [data.data.length, otherData.data.length]
                            // });
                        })
                    } else {

                        // DeviceEventEmitter.emit('msg', {
                        //     deliveredNumber: [data.data.length, 0]
                        // });
                        // this.props.fucn.asd([data.data.length, 0]);

                        this.props.onTitleNumber(data.data.length);
                        // DeviceEventEmitter.emit('msg', {
                        //     homePageNumber: [data.data.length, 0]
                        // });
                    }
                }).catch((err) => {
                    // this.props.fucn.asd([data.data.length, 0]);
                    // DeviceEventEmitter.emit('msg', {
                    //     deliveredNumber: [data.data.length, 0]
                    // });
                    this.props.onTitleNumber(data.data.length);
                });


                global.storage.save({
                    key: 'showOrders',
                    data: true,
                    expires: null
                });

                this.setState({
                    newOrderData: data,
                    loadingData: "loaded",
                    orderSize: data.data.length
                })
            });
        }
            , error => {

            }
        );
        this.setState({
            showOrders: true
        })
    }

    async componentDidMount() {


        // this.refs._scrollView.scrollTo({x: 1440,y:1440, animated: false});
        NativeModules.ToastExample.show("asd", 0, (data) => {
            data = JSON.parse(data);
            global.storage.save({
                key: 'location',
                data: data,
                expires: null
            });
        });

        InteractionManager.runAfterInteractions(() => {
            // this.setState({showOrders: false});
        });

        global.storage.load({
            key: 'showOrders'
        }).then(ret => {
            if (!this.state.showOrders && ret == true) {
                this.setState({
                    showOrders: ret
                })
                setTimeout(() => {
                    this.getData();
                }, 20);
            }
        }).catch((err) => {

        });
    }

    showDailog(item, _this) {
        _this.setState({
            // isVisible: true,
            item: item
        })

        let info = "";
        //  !item.orderPaidStatus ? "Did you pay sotre.  "+item.driverPaid:"";

        if (!item.orderPaidStatus) info = "Did you pay store €" + item.driverPaid;
        if (!item.orderPaidStatus) info = "Did the store pay you €" + item.storePaid;
        Alert.alert('', 'Did you collect all delivery items? \n ' + info,
            [
                {
                    text: "Yes", onPress: () => {
                        this.updateData(item, _this, "Yes");
                    }
                },
                // {text:"No", onPress:this.updateData(item, _this,"No")},
                {
                    text: "No", onPress: () => {

                    }
                },
            ]
        );
        // setTimeout(function () { _this.setState({ isVisible: false }) }, 10000);this.confirm

    }
    updateData(item, _this, type) {
        Update({
            orderId: item.orderId,
            updateStatus: "collected",
            status: "new",
            type: 'current',
            driverModel: {
                driverId: "d001"
            }
        }).then((data) => {
            _this.getData()
        });
    }

    returnData(data) {
        this.Vdata = data;
        this.setState({ viewIndex: data });
    }

    // handleScroll: function(event: Object) {
    //     console.log(event.nativeEvent.contentOffset.y);
    //    },
    handleScroll(event) {
        alert(JSON.stringify(event.nativeEvent));
    }

    _rederData = (item, index, _this) => {
        let swi = width / 2 - 8;    
        let windex = (this.state.windex-1)*5;
        return <View style={[AppStyles.mainTabContainer, {
            width: width
        }]}>
            <ScrollView
                keyboardDismissMode='on-drag'
                keyboardShouldPersistTaps='never'
                showsVerticalScrollIndicator={true}
                scrollEnabled={true}
                pagingEnabled={true}
                horizontal={false}
                style={{
                    height: height - 300,
                    flex: 1,
                    flexDirection: 'column'
                }}
            >
                <View style={{ height: 1 }}>
                </View>
                <View style={AppStyles.middleButton}>
                    <View style={{
                        flex: 1, flexDirection: 'row',
                        justifyContent: 'space-between',
                        width: width
                    }}>
                        <View style={[AppStyles.middleButtonLeft, { width: width / 2 - 8 }, AppStyles.middleButton, { height: (width / 2 - 8) * 0.42,
                            borderLeftWidth: 4 }]}>
                            <TouchableHighlight
                                onPress={() => {
                                    var path = {
                                        pathname: '/Chat',
                                        state: {
                                            returnData: _this.returnData.bind(_this),
                                            index: index + 1,
                                            destination: {
                                                latitude: item.latitude,
                                                longitude: item.longitude
                                            },
                                            data: item
                                        }
                                    }
                                    this.props.history.push(path);
                                    // this.props.navigation.navigate('Chat', {
                                    //     destination: {
                                    //         latitude: item.latitude,
                                    //         longitude: item.longitude
                                    //     },
                                    //     onGoBack: () => {
                                    //         this.props.navigation.navigate.push("test");
                                    //     },
                                    // })
                                }}
                            >
                                <View style={{
                                    flexDirection: 'row', justifyContent: "space-between", borderWidth: 2,
                                    borderColor: "#ff544f", height: (width / 2 - 8) * 0.42, paddingLeft: 5, fontWeight: "bold"
                                }}>
                                    <View>
                                        <Text style={styles.activeFont}>Route to</Text>
                                        <Text style={styles.activeFont}>Customer</Text>
                                    </View>
                                    <View style={[{
                                        borderRadius: 45,
                                        backgroundColor: "#ff544f",
                                        width: 45,
                                        height: 45,
                                        margin: 5,
                                        fontSize: 25
                                    }, styles.center]}>
                                        <Text style={styles.iconStyle}>&#xe602;</Text>
                                    </View>
                                </View>
                            </TouchableHighlight>
                        </View>
                        <View style={[AppStyles.middleButtonRight, {
                            width: width / 2 - 8,
                            flexDirection: 'row', justifyContent: "space-between"
                        },
                        AppStyles.middleButton,
                        {
                        borderLeftWidth: 4,
                        borderLeftColor: "#ffffff",
                        }]}>
                            <View
                                style={{width:swi*.6}}
                            >
                                <Text style={styles.activeFont}>Pick Up </Text>
                                <Text style={[styles.activeFont, { fontSize: 15 }]}>In
                                    {" "}
                                    {
                                        (item.pickUpEnd - item.pickUpStart) / 60000
                                    }
                                    {" "} Mins
                                </Text>
                            </View>
                            <View style={[{
                                backgroundColor: "#f0695a", padding: 5,
                                width: swi * .35
                            }, AppStyles.middleButton, styles.center]}>
                                <TouchableHighlight
                                    onPress={() => { Linking.openURL(`tel:` + item.phone) }}
                                    style={{ backgroundColor: "#f0695a" }}
                                >
                                    <Text style={[{
                                        borderRadius: 40,
                                        borderColor: "#f0695a",
                                        borderWidth: 1,
                                        width: 40,
                                        height: 40,
                                        fontSize: 45,
                                        padding: 0,
                                        backgroundColor: "#ffffff",
                                        color: '#f0695a',
                                        fontFamily: 'iconfont'
                                    }]}>&#xe60a;</Text>
                                </TouchableHighlight>
                            </View>
                        </View>
                    </View>
                </View>
                <View style={{ justifyContent: "center", flexDirection: 'row', marginTop: 15 }}>
                    <Text style={[styles.iconStyle, { color: "#ff544f" }]}>&#xe604;</Text>
                    <View style={{ paddingLeft: 5 }}>
                        <Text style={{ width: width * .85 }}>
                            {item.address}
                        </Text>
                    </View>
                </View>
                <View style={{ width: width - 16, margin: 8, height: 1, backgroundColor: "#f7f7f7" }}></View>
                <View style={{
                    flex: 1, flexDirection: 'row',
                    justifyContent: 'space-between',
                    width: width - 16, margin: 8, height: 50, paddingLeft: 15, paddingRight: 15
                }}>
                    <View>
                        <Text style={{ fontSize: 20, fontWeight: "bold" }}>{item.orderId}</Text>
                        <Text style={{ fontSize: 20, fontWeight: "bold" }}>{item.time} Mins ({item.distance} KM)</Text>
                    </View>
                    <View>
                        <Text style={{ fontSize: 25, fontWeight: "bold", color: "#ff544f" }}>€{item.deliverFee.toFixed(2)}</Text>
                    </View>
                </View>
            </ScrollView>
            <View style={{
                flexDirection: 'row',
                width: width,
                justifyContent: "center"
            }}>
                <LineBtn item={item} width={width * .7} showDailog={(item) => {
                    this.showDailog(item, _this);
                }}>
                </LineBtn>
                {/* <View style={{
                    marginTop: 10, width: width - 16, margin: 8, flexDirection: 'row',
                    backgroundColor: "#739e5e",
                    borderRadius: 50
                }}
            >
                <View
                     {...this._panResponder.panHandlers}
                     style={[styles.rect,{
                        // "backgroundColor": this.state.bg,
                        "top": this.state.top,
                        "left": this.state.left
                      }]}
                >
                    {/* {this.state.left>200?alert("123"):""} */}
                {/* <Svg key={`key-1`} icon={"greenslider-arrow-144x144"}
                        fill="#000000"
                        style={{ width: 50, height: 50 }} /> */}
            </View>
            {/* <TouchableHighlight
                    onPress={() => {
                        this.showDailog(item, _this);
                    }}
                    style={{
                        width: width * .6,
                        flex: 0, height: 50,
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}
                >
                    <Text
                        style={{ fontSize: 38, fontWeight: "bold", color: "#FFFFFF" }}>Collect</Text>
                </TouchableHighlight>
            </View>  */}
            <View style={{ flexDirection: 'row', width: width, justifyContent: "center" }}>

                <Text style={{
                    color: "#f0695a",
                    fontFamily: 'iconfont'
                }}>
                    &#xe6bc;
                    </Text>
                <Text style={{
                    width: 80,
                    justifyContent: "center",
                    textAlign: "center"
                }}>
                {windex+index + 1} to {this.state.orderSize}
                    {/* {index + 1} to {this.state.orderSize} */}
                </Text>
                <Text style={{
                    color: "#f0695a",
                    fontFamily: 'iconfont'
                }}>
                    &#xe62d;
                </Text>

            </View>
        </View>
    }
        

    backScoll() {
        let mainData = this.oData;

        let windex = (this.state.windex - 1) * 5;

        let data = this.oData.length / 5;
        if (data < 1) return false;
        let dataL = parseInt(data);
        if (data > dataL) dataL = dataL + 1;

        let sw = this.state.windex - 1;

        if(sw==0) return false;
        if (sw < dataL) {
            let cData = [mainData[windex - 5], mainData[windex - 4], mainData[windex - 3], mainData[windex - 2], mainData[windex - 1]];

            this.setState({
                newOtherOrderData: {
                    data: cData
                },
                windex: this.state.windex - 1
            })
        }

    }

    goScoll() {
        // let mainData = this.state.newOtherOrderData.data;
        let mainData = this.oData;

        let windex = (this.state.windex + 1) * 5;

        let data = this.oData.length / 5;

        // let data = this.state.newOtherOrderData.data.length/5;
        let dataL = parseInt(data);
        if (data > dataL) dataL = dataL + 1;

        let sw = this.state.windex + 1;

        if (sw < dataL) {
            let cData = [];
            if (data > dataL) {
                // let Data1 = null,Data2= null,Data3= null,Data4= null,Data5= null

                cData = [];
                if (mainData[windex + 1]) cData[0] = mainData[windex + 1];

                if (mainData[windex + 2]) cData[1] = mainData[windex + 2];

                if (mainData[windex + 3]) cData[2] = mainData[windex + 3];

                if (mainData[windex + 4]) cData[3] = mainData[windex + 4];

                if (mainData[windex + 5]) cData[4] = mainData[windex + 5];



            } else {
                cData = [mainData[windex + 1], mainData[windex + 2], mainData[windex + 3], mainData[windex + 4], mainData[windex + 5]];

            }

            this.setState({
                newOtherOrderData: {
                    data: cData
                },
                windex: this.state.windex + 1
            })
        }
    }

    /**
     * @render
     * @returns {*}
     */
    render() {
        let initialOffset = {
            x: 1440,
            y: 1440,
        }

        var _this = this;
        let param = null
        const { state } = this.props.location;
        // alert(JSON.stringify(state));
        if (state) param = state;

        let max = width * 4;
        // alert(JSON.stringify(this.state.viewIndex));


        let pageData = [];
        if(this.state.newOrderData) {
            let DataSize = this.state.newOrderData.data.length/5;


            for(let i = 0; i < DataSize;i++){
                pageData.push({
                    index:i
                })
            }
            // let 


        }
        if(this.state.back){
            initialOffset.x=max
        }

        return (<View style={{ width: width, height: height - 170 }}>
                <View style={{backgroundColor:"#ffffff",width: width, height: height - 170}}>

                </View>
            {
                this.state.showOrders ? (
                    this.state.newOrderData ?
                        <View style={styles.scroll}>
                            <View>
                                {
                                    pageData.map((data, index) => 
                                    data.index == this.state.sid ? <ScrollView
                                            horizontal
                                            keyboardShouldPersistTaps="handled"
                                            bounces={true}
                                            alwaysBounceHorizontal={true}
                                            // scrollsToTop={true}
                                            showsHorizontalScrollIndicator={false}
                                            automaticallyAdjustContentInsets={false}
                                            // canCancelContentTouches={true}
                                            // overScrollMode="never"
                                            scrollTo={{ x:  1000, y: 0 }}
                                            pagingEnabled={true}
                                            contentOffset={{x:1000,y:0}}
                                            // onScroll={this.handleScroll.bind(this)}
                                            // refreshControl={data=>alert(data)}
                                            removeClippedSubviews
                                            alwaysBounce={true}
                                            bouncesZoom={true}
                                            ref='_scrollView'
                                            onLayout={() => {
                                                if(this.state.back){
                                                    this.refs._scrollView.scrollTo({ x: initialOffset.x });
                                                }
                                        
                                            }}
                                            
                                            onScrollEndDrag={(event) => {
                                                // alert(JSON.stringify(event.nativeEvent));

                                                // this.refs._scrollView.scrollTo({x: max,y:max, animated: false});
                                                // alert(event.nativeEvent.contentOffset.x );
                                                if (event.nativeEvent.contentOffset.x == 0 && this.state.sid!=0 ) {
                                                    // this.refs._scrollView.scrollTo(max, 0, false);
                                                    // this.refs._scrollView.scrollTo({x: max,y:max, animated: false});
                                                    // this.refs._scrollView.scrollTo({x: 1000, animated: false}), 100);
                                                    this.setState({
                                                        sid: this.state.sid-1,
                                                        back: this.state.sid
                                                    });
                                                }
                                                // this.backScoll();

                                                if (event.nativeEvent.contentOffset.x == max) {
                                                    this.setState({
                                                        sid: this.state.sid+1,
                                                        back: false
                                                    });
                                                    // this.refs._scrollView.scrollTo(0, 0, false);
                                                    // this.goScoll();
                                                }
                                            }}
                                        >
                                            {this.state.newOrderData.data.map((data, index) => 
                                                 index >= this.state.sid*5 && index < (this.state.sid+1)*5
                                                 &&data!=null ?  this._rederData(data, index, _this):null)}
                                            {/* {this.state.newOrderData.data.map((data, index) => 
                                                this._rederData(data, index, _this))} */}
                                        </ScrollView>:null
                                    )
                                }
                            </View>

                            {
                                // this.state.leftData ? <Animated.ScrollView
                                //     horizontal
                                //     keyboardShouldPersistTaps="handled"
                                //     bounces={true}
                                //     alwaysBounceHorizontal={true}
                                //     scrollsToTop={true}
                                //     showsHorizontalScrollIndicator={false}
                                //     automaticallyAdjustContentInsets={false}
                                //     // canCancelContentTouches={true}
                                //     // overScrollMode="never"
                                //     scrollTo={{ x: 0, y: 0 }}
                                //     pagingEnabled={true}
                                //     contentOffset={initialOffset}
                                //     // onScroll={this.handleScroll.bind(this)}
                                //     // refreshControl={data=>alert(data)}
                                //     removeClippedSubviews
                                //     alwaysBounce={true}
                                //     bouncesZoom={true}
                                //     ref='_scrollView'
                                //     onScrollEndDrag={(event) => {
                                //         // alert(JSON.stringify(event.nativeEvent.contentOffset.x));

                                //         if (event.nativeEvent.contentOffset.x == 0) this.backScoll();

                                //         if (event.nativeEvent.contentOffset.x == max) {
                                //             this.setState({
                                //                 leftData:false
                                //             })
                                //             // this.refs._scrollView.scrollTo(0, 0, false);
                                //             // this.goScoll();
                                //         }
                                //     }}
                                // >
                                //     {this.state.newOrderData.data.map((data, index) => 
                                //         index < 5&&data!=null ?  this._rederData(data, index, _this):null)}
                                //     {/* {this.state.newOrderData.data.map((data, index) => 
                                //         this._rederData(data, index, _this))} */}
                                // </Animated.ScrollView> : null
                            }
                            
                        </View> : null
                ) : (
                        <View>
                            <View style={{
                                marginTop: 50,
                                width: width,
                                justifyContent: "center",
                                textAlign: "center"
                            }}>
                                <Text style={{
                                    width: width,
                                    justifyContent: "center",
                                    textAlign: "center"
                                }}>
                                    Work as a store driver start here
                                </Text>
                                <View style={{marginTop: 60}}>

                                    <LineBtn item={{}} width={width - 16} title={"Start Shift"} showDailog={(item) => {
                                        this.startShift();
                                    }}>
                                    </LineBtn>

                                </View>
                                {/* <View style={{
                                    marginTop: 60, width: width - 16, margin: 8, flexDirection: 'row',
                                    backgroundColor: "#739e5e",
                                    borderRadius: 50
                                }}
                                >
                                    <Svg key={`key-1`} icon={"greenslider-arrow-144x144"}
                                        fill="#000000"
                                        style={{ width: 50, height: 50 }} />
                                    <TouchableHighlight
                                        //onPress={() => {this.popUp.show()}}
                                        onPress={() => {
                                            this.startShift()
                                        }}

                                        style={{
                                            width: width * .6,
                                            flex: 0, height: 50,
                                            alignItems: 'center',
                                            justifyContent: 'center'
                                        }}
                                    >
                                        <Text
                                            style={{
                                                fontSize: 38,
                                                fontWeight: "bold",
                                                color: "#FFFFFF"
                                            }}>
                                            Start Shift</Text>
                                    </TouchableHighlight>
                                </View> */}

                            </View>
                        </View>
                    )
            }
        </View>
        )
    }
}
const styles = StyleSheet.create({
    iconStyle: {
        color: '#ffffff',
        fontFamily: 'iconfont',
        fontSize: 20
    },
    scroll: {
        overflow: 'scroll'
    },
    activeFont: {
        fontSize: 24,
        fontWeight: "bold",
        color: "#000000"
    },
    center: {

        textAlign: 'center',
        alignItems: 'center',
        justifyContent: 'center',
        textAlignVertical: 'center'
    }
})
// export default StackNavigator({
//     Main: {screen: ChinaTown}
//   });
export default ChinaTown;