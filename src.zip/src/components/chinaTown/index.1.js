
import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    Dimensions,
    TouchableHighlight,
    Animated,
    ScrollView,
    TouchableNativeFeedback,
    Linking,
    Alert,
    DeviceEventEmitter
} from 'react-native';

// import firebase from 'react-native-firebase';
// import type { Notification, NotificationOpen, RemoteMessage } from 'react-native-firebase';
// import PageScrollView from 'react-native-page-scrollview';
// import type { Notification } from 'react-native-firebase';
// import FCM, {
//     FCMEvent, RemoteNotificationResult,
//     WillPresentNotificationResult, NotificationType
// } from "react-native-fcm";

const { width, height } = Dimensions.get('window');
import AppStyles from "./style";
// import { AsyncStorage } from 'react-native';

import Svg from "../../../icons/icons";

// import Overlay from "react-native-elements";
// import { Overlay } from 'react-native-elements';

import { OrderQuery, Update } from "../../api";

// import { Button as ELButton } from 'react-native-elements';

// import Storage from 'react-native-storage';
// global.storage = storage;
/**
 * @app
 */
class ChinaTown extends React.Component {

    /**
     * @constructor
     * @param props
     */
    constructor(props) {
        super(props);

        this.token = null;


        let initialVisibility = 1;

        const tabWidth = width;

        const initialOffset = {
            x: this._getScrollAmount(1, 1),
            y: 0,
        }

        this.listingData = false;
        this.count = 1;
        this.state = {
            index: 0,
            orderSize: 1,
            notif: null,
            payload: null,
            newOrderData: null,
            showOrders: false,

            visibility: new Animated.Value(initialVisibility),
            scrollAmount: new Animated.Value(0),
            initialOffset,
            isVisible: false,
            item: null,
            listingData: null,
            loadingData: ""
        }
        // const firebaseConfig = {
        //     apiKey: "AIzaSyDPTi3QK2n0vKFIA7Yp3R6nhp2bbZseivs",
        //     authDomain: "fir-19447.firebaseapp.com"
        // };
        // const firebaseConfig = {
        //     apiKey: "AIzaSyAoT8Z6d8sdQTOcyabo4OUQY9g2wSGZTHw",
        //     authDomain: "easydish-af2a7.firebaseapp.com"
        // };
        // firebase.initializeApp(firebaseConfig);

    }

    _getScrollAmount = (i) => {
        const tabWidth = width;
        const centerDistance = tabWidth * (i + 1 / 2);
        const scrollAmount = centerDistance - width / 2;

        return this._normalizeScrollValue(scrollAmount);
    };

    _normalizeScrollValue = (value, size) => {
        const tabWidth = width;
        const tabBarWidth = Math.max(
            tabWidth * size,
            width
        );
        const maxDistance = tabBarWidth - width;

        return Math.max(Math.min(value, maxDistance), 0);
    };

    // async msg() {
    //     const fcmToken = await firebase.messaging().getToken();
    //     if (fcmToken) {
    //         console.log(`令牌为：${fcmToken}`)
    //     } else {
    //         // user doesn't have a device token yet
    //         alert('user doesn\'t have a device token yet')
    //     }
    // }

    //     // Optional: Flow type
    // import type { Notification } from 'react-native-firebase';

    // async componentDidMount() {

    //     firebase.auth()
    //         .signInAnonymouslyAndRetrieveData()
    //         .then(credential => {
    //             if (credential) {
    //                 console.log('default app user ->', credential.user.toJSON());
    //             }
    //         });

    //     const enabled = await firebase.messaging().hasPermission();
    //     if (enabled) {
    //         // alert(enabled);
    //     } else {
    //         alert("false");
    //     }

    //     const channel = new firebase.notifications.Android.Channel('test-channel', 'Test Channel',
    //         firebase.notifications.Android.Importance.Max).setDescription('My apps test channel');
    //     firebase.notifications().android.createChannel(channel);

    //     const notificationOpen = await firebase.notifications().getInitialNotification();
    //     if (notificationOpen) {
    //         // App was opened by a notification
    //         // Get the action triggered by the notification being opened
    //         const action = notificationOpen.action;
    //         // Get information about the notification that was opened
    //         const notification = notificationOpen.notification;
    //     }

    //     try {
    //         await firebase.messaging().requestPermission();
    //     } catch (error) {
    //         alert(error);
    //     }

    //     this.notificationOpenedListener = firebase.notifications().onNotificationOpened((notificationOpen) => {
    //         // Get the action triggered by the notification being opened
    //         const action = notificationOpen.action;
    //         alert(action);

    //         // Get information about the notification that was opened
    //         const notification = notificationOpen.notification;
    //         alert(notification);
    //     });

    //     this.notificationDisplayedListener = firebase.notifications().onNotificationDisplayed((notification: Notification) => {
    //         // Process your notification as required    
    //         // ANDROID: Remote notifications do not contain the channel ID. You will have to specify this manually if you'd like to re-display the notification.
    //         // console.log(notification);
    //         // notification.android.setChannelId(notification.data.channelId || "UNKNOW");
    //         // notification.setTitle(notification.title || "AppName");
    //         // firebase.notifications().displayNotification(notification);
    //         alert(notification.title)
    //         // alert(JSON.stringify(notification.data))
    //         alert(notification.body)
    //         // alert(JSON.stringify(notification))
    //         notification.android.setChannelId(notification.data.channelId || "UNKNOW");
    //         notification.setTitle(notification.title || "AppName");
    //         firebase.notifications().displayNotification(notification);
    //     });

    //     this.messagingListener = firebase.messaging().subscribeToTopic("order").then((data) => {

    //     });

    //     this.notificationListener = firebase.notifications().onNotification((notification: Notification) => {
    //         // Process your notification as required

    //         alert('onNotification2')
    //         notification.android.setChannelId(notification.data.channelId || "UNKNOW");
    //         notification.setTitle(notification.title || "AppName");
    //         firebase.notifications().displayNotification(notification);

    //     });
    // }

    componentWillUnmount() {


        // navigator.geolocation.getCurrentPosition(
        //     location => {
        //         global.storage.save({
        //             key: 'location',
        //             data: {
        //                 latitude: location.coords.latitude,
        //                 longitude: location.coords.longitude
        //             },
        //             expires: null
        //         });
        // })
        // this.notificationOpenedListener();
        
    }

    startShift() {

        global.storage.save({
            key: 'ShiftChinaTown',
            data: true,
            expires: null
        });
        this.getData();
    }
    getData(data){
        // global.storage.load({
        //     key: 'location'
        // }).then(locations => {
        //     alert(JSON.stringify(locations));
        // })

        global.storage.load({
            key: 'location'
        }).then(locations => {
                OrderQuery({
                    status: 'new', type: 'current',
                    shopModel: { shopId: '2321321jb' },
                    driverModel: {
                        latitude: locations.latitude,
                        longitude: locations.longitude,
                        name: 'Jim',
                        driverId: 'd001'
                    }
                }).then((data) => {
                    let ShiftOhters = global.storage.load({
                        key: 'ShiftOhters'
                    }).then(ret => {
                        // console.log(ret.userid);
                        if (ret) {

                            OrderQuery({
                                status: 'new', type: 'others',
                                shopModel: { shopId: '2321321jb' },
                                driverModel: {
                                    latitude: locations.latitude,
                                    longitude: locations.longitude,
                                    name: 'Jim',
                                    driverId: 'd001'
                                }
                            }).then((otherData) => {
                                DeviceEventEmitter.emit('msg', {
                                    homePageNumber: [data.data.length, otherData.data.length]
                                });
                            })
                        } else {
                            DeviceEventEmitter.emit('msg', {
                                homePageNumber: [data.data.length, 0]
                            });
                        }
                    })
                    

                    // let count = this.state.count;
                    // setTimeout(function () {

                    //     OrderQuery({status:'new',type: 'others',
                    //     shopModel:{shopId:'2321321jb'},
                    //     driverModel:{latitude:location.coords.latitude,
                    //         longitude:location.coords.longitude,
                    //         name: 'Jim',
                    //         driverId: 'd001'
                    //     }
                    //     }).then((otherData) => {
                    //         DeviceEventEmitter.emit('msg', {
                    //             homePageNumber:  [data.data.length,otherData.data.length]
                    //         });
                    //     })

                    // }, 300);

                    global.storage.save({
                        key: 'showOrders',
                        data: true,
                        expires: null
                    });

                    this.setState({
                        newOrderData: data,
                        loadingData:"loaded",
                        orderSize: data.data.length
                    })
                });
            }
            , error => {

            }
        );
        this.setState({
            showOrders: true
        })
    }

    componentDidMount() {

        global.storage.load({
            key: 'showOrders'
        }).then(ret => {
            if (!this.state.showOrders && ret == true) {
                this.setState({
                    showOrders: ret
                })
                this.getData();
            }
        })
    }

    showDailog(item, _this) {
        _this.setState({
            // isVisible: true,
            item: item
        })

        let info = "";
        // item ? "Did you pay sotre. ":""
        Alert.alert('', 'Did you collect all delivery items? \n Did you pay sotre.  ',
            [
                { text: "Yes", onPress: this.updateData(item, _this, "Yes") },
                // {text:"No", onPress:this.updateData(item, _this,"No")},
                {
                    text: "No", onPress: () => {

                    }
                },
            ]
        );
        // setTimeout(function () { _this.setState({ isVisible: false }) }, 10000);this.confirm

    }
    updateData(item, _this, type) {
        Update({
            orderId: item.orderId,
            updateStatus: "collected",
            status: "new",
            type: 'current',
            driverModel: {
                driverId: "d001"
            }
        }).then((data) => {
            _this.getData()
        });
    }
    _rederData = (item, index, _this) => <TouchableNativeFeedback>
        <View style={[AppStyles.mainTabContainer, {
            width: width
        }]}>
            <ScrollView

                keyboardDismissMode='on-drag'
                keyboardShouldPersistTaps='never'
                showsVerticalScrollIndicator={true}
                scrollEnabled={true}
                pagingEnabled={true}
                horizontal={false}
                style={{
                    height: height - 240,
                    flex: 1,
                    flexDirection: 'column'
                }}>
                <View style={{ height: 5 }}>
                </View>
                <View style={AppStyles.middleButton}>
                    <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'space-between', width: width }}>

                        <View style={[AppStyles.middleButtonLeft, { width: width / 2 - 8 }, AppStyles.middleButton, { height: (width / 2 - 8) * 0.42 }]}>
                            <TouchableHighlight
                                onPress={() => {
                                    this.props.navigation.navigate('Chat', {
                                        destination: {
                                            latitude: item.latitude,
                                            longitude: item.longitude
                                        },
                                        routeName: "test",
                                        onGoBack: () => {
                                            this.props.navigation.navigate.push("test");
                                        },
                                    })
                                }}
                            >
                                <View style={{
                                    flexDirection: 'row', justifyContent: "space-between", borderWidth: 2,
                                    borderColor: "#ff544f", height: (width / 2 - 8) * 0.42, paddingLeft: 5, fontWeight: "bold"
                                }}>
                                    <View>
                                        <Text style={styles.activeFont}>Route to</Text>
                                        <Text style={styles.activeFont}>Customer</Text>
                                    </View>
                                    <View style={[{
                                        borderRadius: 45,
                                        backgroundColor: "#ff544f",
                                        width: 45,
                                        height: 45,
                                        margin: 5,
                                        fontSize: 25
                                    }, styles.center]}>
                                        <Text style={styles.iconStyle}>&#xe602;</Text>
                                    </View>
                                </View>
                            </TouchableHighlight>
                        </View>
                        <View style={[AppStyles.middleButtonRight, {
                            width: width / 2 - 7,
                            flexDirection: 'row', justifyContent: "space-between"
                        },
                        AppStyles.middleButton]}>
                            <View>
                                <Text style={styles.activeFont}>Pick Up </Text>
                                <Text style={[styles.activeFont, { fontSize: 15 }]}>In {
                                    ((new Date(item.pickUpStart)).getTime() - (new Date(item.pickUpEnd)).getTime()) / 60000
                                } Mins</Text>
                            </View>
                            <View style={[{
                                backgroundColor: "#f0695a", padding: 5,
                                width: width * .15
                            }, AppStyles.middleButton, styles.center]}>
                                <TouchableHighlight
                                    onPress={() => { Linking.openURL(`tel:` + item.phone) }}
                                    style={{ backgroundColor: "#f0695a" }}
                                >
                                    <Text style={[{
                                        borderRadius: 40,
                                        borderColor: "#f0695a",
                                        borderWidth: 1,
                                        width: 40,
                                        height: 40,
                                        fontSize: 45,
                                        padding: 0,
                                        backgroundColor: "#ffffff",
                                        color: '#f0695a',
                                        fontFamily: 'iconfont'
                                    }]}>&#xe60a;</Text>
                                </TouchableHighlight>
                            </View>
                        </View>
                    </View>
                </View>
                <View style={{ justifyContent: "center", flexDirection: 'row', marginTop: 15 }}>
                    <Text style={[styles.iconStyle, { color: "#ff544f" }]}>&#xe604;</Text>
                    <View style={{ paddingLeft: 5 }}>
                        <Text style={{ width: width * .85 }}>
                            {item.address}
                        </Text>
                    </View>
                </View>
                <View style={{ width: width - 16, margin: 8, height: 1, backgroundColor: "#f7f7f7" }}></View>
                <View style={{
                    flex: 1, flexDirection: 'row',
                    justifyContent: 'space-between',
                    width: width - 16, margin: 8, height: 50, paddingLeft: 15, paddingRight: 15
                }}>
                    <View>
                        <Text style={{ fontSize: 20, fontWeight: "bold" }}>{item.orderId}</Text>
                        <Text style={{ fontSize: 20, fontWeight: "bold" }}>{item.time} Mins ({item.distance} KM)</Text>
                    </View>
                    <View>
                        <Text style={{ fontSize: 25, fontWeight: "bold", color: "#ff544f" }}>€{item.deliverFee.toFixed(2)}</Text>
                    </View>
                </View>
            </ScrollView>
            <View style={{
                marginTop: 10, width: width - 16, margin: 8, flexDirection: 'row',
                backgroundColor: "#739e5e",
                borderRadius: 50
            }}
            // onPress={() => {
            //     Update({
            //         'orderId':item.orderId,
            //         'updateStatus': 'collected',
            //         'status': 'new',
            //         'type': 'current',
            //         'driverModel': {
            //             'driverId': 'd001'  
            //         }
            //     }).then((data) => {
            //         this.getData()
            //     }).catch( (err) => {
            //         alert(err);
            //         reject(err);
            //     });
            // }}
            >
                <Svg key={`key-1`} icon={"greenslider-arrow-144x144"}
                    fill="#000000"
                    style={{ width: 50, height: 50 }} />
                <TouchableHighlight
                    onPress={() => {
                        this.showDailog(item, _this);
                    }}
                    style={{
                        width: width * .6,
                        flex: 0, height: 50,
                        alignItems: 'center',
                        justifyContent: 'center'
                    }}
                >
                    <Text
                        style={{ fontSize: 38, fontWeight: "bold", color: "#FFFFFF" }}>Collect</Text>
                </TouchableHighlight>
            </View>
            <View style={{ flexDirection: 'row', width: width, justifyContent: "center" }}>

                <Text style={{
                    color: "#f0695a",
                    fontFamily: 'iconfont'
                }}>
                    &#xe6bc;
                    </Text>
                <Text style={{
                    width: 80,
                    justifyContent: "center",
                    textAlign: "center"
                }}>
                    {index + 1} to {this.state.orderSize}
                </Text>
                <Text style={{
                    color: "#f0695a",
                    fontFamily: 'iconfont'
                }}>
                    &#xe62d;
                </Text>

            </View>
        </View>
    </TouchableNativeFeedback>

    /**
     * @render
     * @returns {*}
     */
    render() {
        let initialOffset = {
            x: this._getScrollAmount(this.state.index, this.state.orderSize),
            y: 0,
        }

        var _this = this;

        return (
            <View>
                {
                    this.state.showOrders ? (
                        this.state.newOrderData ?
                            <View style={styles.scroll}>
                                <Animated.ScrollView
                                    horizontal
                                    keyboardShouldPersistTaps="handled"
                                    alwaysBounceHorizontal={false}
                                    scrollsToTop={false}
                                    showsHorizontalScrollIndicator={false}
                                    automaticallyAdjustContentInsets={false}
                                    pagingEnabled={true}
                                    overScrollMode="never"
                                    contentOffset={initialOffset}
                                >
                                    {JSON.parse(JSON.stringify(this.state.newOrderData)).data.map((data, index) => this._rederData(data, index, _this))}
                                </Animated.ScrollView>
                                
                            </View> : null
                    ) : (
                            <View>
                                <View style={{
                                    marginTop: 50,
                                    width: width,
                                    justifyContent: "center",
                                    textAlign: "center"
                                }}>
                                    <Text style={{
                                        width: width,
                                        justifyContent: "center",
                                        textAlign: "center"
                                    }}>
                                        Work as a store driver start here
                                    </Text>

                                    <View style={{
                                        marginTop: 60, width: width - 16, margin: 8, flexDirection: 'row',
                                        backgroundColor: "#739e5e",
                                        borderRadius: 50
                                    }}
                                    // onPress={() => {
                                    //     this.getData()
                                    // }}
                                    >
                                        <Svg key={`key-1`} icon={"greenslider-arrow-144x144"}
                                            fill="#000000"
                                            style={{ width: 50, height: 50 }} />
                                        <TouchableHighlight
                                            //onPress={() => {this.popUp.show()}}
                                            onPress={() => {
                                                this.startShift()
                                            }}

                                            style={{
                                                width: width * .6,
                                                flex: 0, height: 50,
                                                alignItems: 'center',
                                                justifyContent: 'center'
                                            }}
                                        >
                                            <Text
                                                style={{
                                                    fontSize: 38,
                                                    fontWeight: "bold",
                                                    color: "#FFFFFF"
                                                }}>
                                                Start Shift</Text>
                                        </TouchableHighlight>
                                    </View>

                                </View>
                            </View>
                        )
                }
            </View>
        )
    }
}
const styles = StyleSheet.create({
    iconStyle: {
        color: '#ffffff',
        fontFamily: 'iconfont',
        fontSize: 20
    },
    scroll: {
        overflow: 'scroll'
    },
    activeFont: {
        fontSize: 24,
        fontWeight: "bold",
        color: "#000000"
    },
    center: {

        textAlign: 'center',
        alignItems: 'center',
        justifyContent: 'center',
        textAlignVertical: 'center'
    }
})
// export default StackNavigator({
//     Main: {screen: ChinaTown}
//   });
export default ChinaTown;