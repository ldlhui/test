
import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Dimensions,
    Button,
    TouchableHighlight,
    WebView,
    ListView,
    ScrollView
} from 'react-native';

const { width, height } = Dimensions.get('window');
import AppStyles from "./style";

import Svg from "../../../icons/icons";

import EndBtn from "../endBtn";

import { OrderQuery, Update, endShift, easyDishDelivered } from "../../api";

import MillisecondToDate from "../../unitl/date";

/**
 * @app
 */
class ChinaTown extends React.Component {

    /**
     * @constructor
     * @param props
     */
    constructor(props) {
        super(props);
        let ds = new ListView.DataSource({ rowHasChanged: (r1, r2) => r1 !== r2 });
        this.state = {
            dataSource: ds.cloneWithRows([{ a: "asd" }, { a: "asd" }, { a: "asd" }]),
            showOrdersTime: null,
            newOtherOrderData: null
        }
    }

    onPressLearnMore() {

    }

    componentDidMount() {
        this.getData();
        global.storage.load({
            key: 'ShiftOhtersTime'
        }).then(data => {
            this.setState({
                showOrdersTime: data
            })
        })
    }


    getData() {

        // alert("1");
        // let token = global.storage.load({
        //     key: 'token'
        // })
        easyDishDelivered({
            type: "others",
            status: "delivered",
            shopModel: { shopId: "2321321jb" },
            driverModel: {
                name: "Jim",
                driverId: "d001"
            }
        }
        ).then((data) => {

            //     alert("123");
            // alert(data);
            // alert(JSON.stringify(data))
            this.setState({
                newOtherOrderData: data.data,
                orderSize: data.data.length
            })
        });

        // DailySum({
        //     shopId: "jb00001",
        //     driverId: "0001",
        //     type: "current",
        // }).then((data) => {
        //     // alert(JSON.stringify(data))
        //     this.setState({
        //         totalData: data.data
        //     })
        // });

        this.setState({
            showOrders: true
        })
    }

    endShift() {

        global.storage.save({
            key: 'ShiftOhters',
            data: false,
            expires: null
        });

        endShift({
            status: "onOthers",
            driverId: "d001"
        }).then((otherData) => {

        })

        // this.getData();
    }

    _renderRow = (rowData) => {
        let orderTimeArr = rowData.deliveredTime? rowData.deliveredTime.split(","):false;
        let orderTime = "";
        let orderDate = "";
        try {    
            if(orderTimeArr) {
                orderTime = orderTimeArr[0];
                orderDate = orderTimeArr[1];
            }
        } catch (error) {
            
        }

        return (
            <View style={[AppStyles.middleButton, {
                flexDirection: 'row',
                width: width - 16, height: 120,
                justifyContent: 'space-between',
                marginLeft: 8,
                marginRight: 8,
                marginBottom: 8,
                backgroundColor: '#ffffff',
                justifyContent: "center"
            }]}>
                <View style={{
                    justifyContent: "flex-start",
                    width: (width - 16) * .6,
                    height: 100,
                    backgroundColor: '#ffffff'
                }}>
                    <View style={{
                        flexDirection: 'row',
                        width: width * .5,
                        justifyContent: 'space-between',
                        padding: 10
                    }}>
                        <View
                            style={{
                                borderRightWidth: 1,
                                paddingRight:5,
                                borderColor:"#d6d8d8"
                            }}
                        >
                            <Text style={{
                                color: "#000000",
                                fontSize: 16,
                                fontWeight: "bold"
                            }}>{rowData.orderId}</Text>
                            <Text>{rowData.distance} KM</Text>
                        </View>
                        <View >
                            <Text style={{
                                color: "#000000",
                                fontSize: 16,
                                fontWeight: "bold"
                            }}>
                            {/* Tue 18:12 */}
                            {rowData.orderTime} 
                            </Text>
                            <Text>
                            {rowData.orderDate} </Text>
                        </View>
                    </View>
                    <View>
                        <View style={{ paddingLeft: 10, paddingRight: 10, paddingBottom: 10 }}>
                            <Text>
                                Driving Time:
                                <Text> {rowData.time}  Mins</Text>
                            </Text>
                            <Text>{rowData.address}  </Text>
                        </View>
                    </View>
                </View>
                <View style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    width: (width - 16) * .4,
                    height: 100,
                    backgroundColor: '#f0695a',
                    padding: 10
                }}>
                    {/* <View>
                        <Text style={{
                            fontSize:30,
                            fontWeight:"bold",
                            color:"#ffffff",
                            borderRightWidth:1,
                            borderColor:"#ffffff",
                            padding:5,
                            height:70
                        }}>Paid</Text>
                    </View> */}
                    <View style={{ textAlign: "center" }}>
                        <View style={{
                            fontSize: 14, textAlign: "center",
                            flexDirection: 'row', color: "#ffffff"
                        }}>

                            <Text style={{
                                fontSize: 14, textAlign: "center", fontWeight: "bold",
                                color: "#ffffff"
                            }}>Driver paid:</Text>
                            <Text style={{
                                fontSize: 14, textAlign: "center",
                                color: "#ffffff"
                            }}>€120.50</Text>
                        </View>

                        <View style={{
                            fontSize: 14, textAlign: "center", flexDirection: 'row',
                            color: "#ffffff"
                        }}>

                            <Text style={{
                                fontSize: 14, textAlign: "center", fontWeight: "bold",
                                color: "#ffffff"
                            }}>Delivery: </Text>
                            <Text style={{
                                fontSize: 14, textAlign: "center",
                                color: "#ffffff"
                            }}>€3.50</Text>
                        </View>

                        <View style={{
                            fontSize: 14, textAlign: "center", flexDirection: 'row',
                            color: "#ffffff"
                        }}>

                            <Text style={{
                                fontSize: 14, textAlign: "center", fontWeight: "bold",
                                color: "#ffffff"
                            }}>Total Cost: </Text>
                            <Text style={{
                                fontSize: 14, textAlign: "center",
                                color: "#ffffff"
                            }}>€123.50</Text>
                        </View>
                    </View>
                </View>
            </View>
        )
    }



    endShift() {

        global.storage.save({
            key: 'ShiftOhters',
            data: false,
            expires: null
        });

        endShift({
            status: "onOthers",
            driverId: "d001"
        }).then((otherData) => {

        })
    }
    /**
     * @render
     * @returns {*}
     */
    render() {
        let _this = this;
        var d = new Date();
        return (
            <View style={[AppStyles.mainTabContainer, { width: width,height:height-170 }]}>
                {/* <View>
                    <Text>
                        {JSON.stringify(this.state.newOtherOrderData)}
                    </Text>
                </View> */}
                <ScrollView>
                    {
                        this.state.newOtherOrderData!=null ? this.state.newOtherOrderData.map((data, index) => {
                            return <View>
                                <View style={{ height: 45 }}>
                                    <View style={{
                                        flex: 1, flexDirection: 'row',
                                        justifyContent: 'space-between',
                                        height: 45, width: width - 8
                                    }}
                                    >
                                        <View style={[AppStyles.middleButtonLeft, { width: width - 8 }, AppStyles.middleButton,
                                        { height: 45, backgroundColor: '#f0695a' }]}>
                                            <View style={{
                                                borderWidth: 2,
                                                borderColor: "#f0695a",
                                                height: 45,
                                                paddingLeft: 5,
                                                fontWeight: "bold",
                                                flexDirection: 'row',
                                                justifyContent: "space-between"
                                            }}>
                                                <View style={{ height: 35 }}>
                                                    <Text style={[styles.lineFont, { color: "#ffffff" }]}>{data.name}</Text>
                                                    <Text style={[styles.lineFont, { color: "#ffffff" }]}>{data.phone}</Text>
                                                </View>
                                                <View style={{ flexDirection: 'row', height: 35 }}>
                                                    <Text style={[styles.lineFont, {
                                                        color: "#ffffff",
                                                        width: width * .5 - 10
                                                    }]}>{data.address}</Text>
                                                </View>
                                            </View>
                                        </View>
                                    </View>
                                </View>
                                {
                                    this._renderRow(data)
                                }
                            </View>
                        }):null

                    }

                    {/* <ScrollView style={{height:height*.52}}>
                        <ListView
                            dataSource={this.state.dataSource}
                            renderRow={this._renderRow}
                        />
                    </ScrollView> */}
                </ScrollView>
                {/* <View style={{flexDirection: 'row',
                            justifyContent:"flex-start",
                        }}>
                    <View style={{width:width*.5,flexDirection: 'row',
                            backgroundColor:"#f0695a",
                            borderRadius:50}}
                        onPress={() => { this.props.navigation.push('Chat')}}
                    >
                        
                        <Svg key={`key-1`} icon={"redslider-arrow-144x144"} 
                            fill="#000000"
                            style={{width:50,height:50}}
                        />

                    </View>
                    <View>
                        <TouchableHighlight
                            onPress={() => { this.props.navigation.push('Chat')}}
                            style={{
                                flex:0,
                                alignItems:'center',
                                justifyContent:'center'
                            }}
                        >
                            <Text style={{fontSize:23,fontWeight:"bold",
                                color:"#FFFFFF"}}>End Shift</Text>
                        </TouchableHighlight>
                    </View>
                </View> */}

                <View style={{
                    flexDirection: 'row',
                    justifyContent: "flex-start",
                    padding: 5
                }}>
                    {/* <View style={{width:width*.5,flexDirection: 'row',
                            backgroundColor:"#f0695a",
                            borderRadius:50}}
                        onPress={() => { this.props.navigation.push('Chat')}}
                    >
                        
                        <Svg key={`key-1`} icon={"redslider-arrow-144x144"} 
                            fill="#000000"
                            style={{width:50,height:50}}
                        />

                        <View>
                            <TouchableHighlight
                                onPress={() => { this.props.navigation.push('Chat')}}
                                style={{
                                    flex:0,
                                    alignItems:'center',
                                    justifyContent:'center'
                                }}
                            >
                                <Text style={{
                                    fontSize:23,
                                    fontWeight:"bold",
                                    paddingTop:10,
                                    paddingLeft:5,
                                    color:"#FFFFFF"
                                }}>End Shift</Text>
                            </TouchableHighlight>
                        </View>
                    </View> */}
                    <View style={{
                        flexDirection: 'row',
                        width: width * .5,
                        justifyContent: "center"
                    }}>
                        <EndBtn item={{}} width={width * .45} fontSize={18} title={"End Shift"} showDailog={(item) => {
                            this.endShift(item, _this);
                        }}>
                        </EndBtn>
                    </View>
                    <View style={{ paddingLeft: 20 }}>
                        <View style={{ backgroundColor: "#f5f5f5", padding: 5, paddingLeft: 10, paddingRight: 10 }}>
                            <View>
                                <Text style={{
                                    fontSize: 16,
                                    fontWeight: "bold",
                                    color: "#000000"
                                }}>Shift Started </Text>
                            </View>
                            <View>
                                <Text style={{
                                    fontSize: 16,
                                    fontWeight: "bold",
                                    color: "#000000"
                                }}>
                                    {this.state.showOrdersTime ? MillisecondToDate(d - this.state.showOrdersTime) : ""}
                                </Text>
                            </View>
                        </View>
                    </View>
                </View>
            </View>
        )
    }
}
const styles = StyleSheet.create({
    iconStyle: {
        color: '#ffffff',
        fontFamily: 'iconfont',
        fontSize: 20
    },
    activeFont: {
        fontSize: 24,
        fontWeight: "bold",
        color: "#000000"
    },
    center: {

        textAlign: 'center',
        alignItems: 'center',
        justifyContent: 'center',
        textAlignVertical: 'center'
    }
})
// export default StackNavigator({
//     Main: {screen: ChinaTown}
//   });
export default ChinaTown;