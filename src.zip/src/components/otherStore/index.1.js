
import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Dimensions,
    Button,
    TouchableHighlight,
    WebView,
    Animated,
    TouchableNativeFeedback,
    Linking,
    ScrollView,
    DeviceEventEmitter
} from 'react-native';
import { Overlay } from 'react-native-elements';

const { width, height } = Dimensions.get('window');
import AppStyles from "./style";
// import { Text, View} from 'react-native';
// import PopUp from "../common/popup";
// import {
//     StackNavigator,
//     TabNavigator
// } from 'react-navigation';

import Svg from "../../../icons/icons";
import { OrderQuery, DailySum,Update,startShift } from "../../api";

import LineBtn from "../lineBtn";


/**
 * @app
 */
class ChinaTown extends React.Component {

    /**
     * @constructor
     * @param props
     */
    constructor(props) {
        super(props);

        this.token = null;

        let initialVisibility = 1;

        const initialOffset = {
            x: this._getScrollAmount(1, 1),
            y: 0,
        }

        this.state = {
            index: 0,
            orderSize: 1,
            notif: null,
            payload: null,
            newOtherOrderData: null,
            showOtherOrders: false,
            windex:1,
            visibility: new Animated.Value(initialVisibility),
            scrollAmount: new Animated.Value(0),
            initialOffset,
            isVisible: false
        }
        this.oData = null;
    }

    onPressLearnMore() {

    }
    showDailog(item, _this) {
        _this.setState({
            isVisible: true,
            item: item
        })

        let info = "";
        //  !item.orderPaidStatus ? "Did you pay sotre.  "+item.driverPaid:"";

        // if( !item.orderPaidStatus ) info =  "Did you pay store €"+item.driverPaid;
        // if( !item.orderPaidStatus ) info = "Did the store pay you €"+item.storePaid;
        Alert.alert('', 'Please ensure the order will be  \n picked up on time .\n \n You have 20 seconds to cancel the order \n without receiving negative feedback.' ,
            [
                { text: "Yes", onPress:()=>{
                    this.updateData(item, _this, "Yes");
                }},
                {
                    text: "No", onPress: () => {

                    }
                },
            ]
        );
        // setTimeout(function () { _this.setState({ isVisible: false }) }, 10000);this.confirm

    }
    updateData(item, _this) {
        _this.setState({
            isVisible: true
        })
        setTimeout(function () { _this.setState({ isVisible: false }) }, 10000);
        Update({
            "shopId": item.shopModel.shopId,
            orderId:item.orderId,
            updateStatus: "accepted",
            status: item.status,
            driverModel: {
                driverId: "d001"
            },
            shopModel:{
                shopId:item.shopModel.shopId
            }
        }).then((data) => {
            _this.getData()
        });
    }

    _getScrollAmount = (i) => {
        const tabWidth = width;
        const centerDistance = tabWidth * (i + 1 / 2);
        const scrollAmount = centerDistance - width / 2;

        return this._normalizeScrollValue(scrollAmount);
    };

    _normalizeScrollValue = (value, size) => {
        const tabWidth = width;
        const tabBarWidth = Math.max(
            tabWidth * size,
            width
        );
        const maxDistance = tabBarWidth - width;

        return Math.max(Math.min(value, maxDistance), 0);
    };


    startShift(){

        global.storage.save({
            key:'ShiftOhters',
            data: true,
            expires: null
        });
        var d = new Date();

        global.storage.save({
            key: 'ShiftOhtersTime',
            data: d.getTime(),
            expires: null
        });
        startShift({
            status: "onOthers",
            driverId: "d001"
        }).then((otherData) => {

        })
        this.getData();
    }

    async getData(data) {
        global.storage.load({
            key: 'location'
        }).then(locations => {
                OrderQuery({
                    status: "new",
                    type: "others",
                    shopModel: { shopId: "001bbb" },
                    driverModel: {
                        latitude: locations.latitude,
                        longitude: locations.longitude,
                        name: "Jim",
                        driverId: "d001",
                        allowDistance:"20"
                    }
                }).then((data) => {
                    
                    this.props.onRightNumber(data.data.length);
                    // alert(JSON.stringify(data));
                    // setTimeout(function () {

                    //     OrderQuery({status:'new',type: 'current',
                    //     shopModel:{shopId:'2321321jb'},
                    //     driverModel:{latitude:location.coords.latitude,
                    //         longitude:location.coords.longitude,
                    //         name: 'Jim',
                    //         driverId: 'd001'
                    //     }
                    //     }).then((otherData) => {
                    //         DeviceEventEmitter.emit('msg', {
                    //             homePageNumber:  [datas.data.length,otherData.data.length]
                    //         });
                    //     })
                        
                    // }, 300);
                        
                    // alert(JSON.stringify(data));

                    this.oData = data.data;
                    this.setState({
                        newOtherOrderData: data,
                        orderSize: data.data.length
                    })
                    global.storage.save({
                        key: 'ShiftOhters',
                        data: true,
                        expires: null
                    });
                });
            }
            , error => {

            });
        this.setState({
            showOtherOrders: true
        })
    }


    async componentDidMount() {
        global.storage.load({
            key: 'ShiftOhters'
        }).then(ret => {
            if (!this.state.showOtherOrders && ret == true) {
                this.setState({
                    showOtherOrders: ret
                })
                this.getData();
            }
        })
    }

    _rederOtherData = (item, index) => {

        let windex = this.state.windex;
        let _this = this;
        return <TouchableNativeFeedback>
            <View style={[AppStyles.mainTabContainer, { 
                width: width,
                height:height-210}]}>
                <ScrollView 
                    keyboardDismissMode='on-drag'
                    keyboardShouldPersistTaps='never'
                    showsVerticalScrollIndicator={true}
                    scrollEnabled={true}
                    pagingEnabled={true}
                    horizontal={false}
                    style={{
                        flex: 1,
                        flexDirection: 'column'
                    }}
                >
                    <View style={{ height: 100 }}>
                        <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'space-between', width: width / 2 - 8 }}>
                            <View style={[AppStyles.middleButtonLeft, { width: width * .8 - 8 }, AppStyles.middleButton,
                            { height: 100, backgroundColor: '#f0695a' }]}>
                                <View style={{
                                    borderWidth: 2,
                                    borderColor: "#f0695a", height: (width / 2 - 8) * 0.42, paddingLeft: 5, fontWeight: "bold"
                                }}>
                                    <View style={{ flexDirection: 'row', height: 25 }}>
                                        <Text style={styles.iconStyle}>&#xe606;</Text>
                                        <Text style={[styles.lineFont, { color: "#ffffff" }]}> {item.shopModel.name} </Text>
                                    </View>
                                    <View style={{ flexDirection: 'row', height: 25 }}>
                                        <Text style={styles.iconStyle}>&#xe609;</Text>
                                        <Text style={[styles.lineFont, { color: "#ffffff" }]}> {item.shopModel.phone} </Text>
                                    </View>
                                    <View style={{ flexDirection: 'row', minHeight: 25 }}>
                                        <Text style={styles.iconStyle}>&#xe607;</Text>
                                        <Text style={[styles.lineFont, { color: "#ffffff", width: width * .8 - 30 }]}>
                                            {item.shopModel.address}
                                        </Text>
                                    </View>
                                </View>
                            </View>
                            <View style={[AppStyles.middleButtonRight, { width: width * .2 }, AppStyles.middleButton,
                            { height: 100, backgroundColor: '#f0695a', borderRightColor: "#f0695a" }]}>
                                <TouchableHighlight
                                    onPress={() => { Linking.openURL(`tel:` + item.shopModel.phone) }}
                                >
                                    <View style={{
                                        flexDirection: 'row', justifyContent: "flex-end", borderWidth: 2,
                                        borderColor: "#f0695a", height: (width / 2 - 8) * 0.42,
                                        paddingLeft: 5, fontWeight: "bold"
                                    }}>
                                        <Text style={[{
                                            borderRadius: 45,
                                            width: 45,
                                            height: 45,
                                            fontSize: 45,
                                            padding: 0,
                                            color: '#ffffff',
                                            fontFamily: 'iconfont'
                                        }]}>&#xe60a;</Text>
                                    </View>
                                </TouchableHighlight>
                            </View>
                        </View>
                    </View>
                    <View style={{ height: 1 }}>
                    </View>
                    <View style={AppStyles.middleButton}>
                        <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'space-between', width: width }}>

                            <View style={[AppStyles.middleButtonLeft, { width: width / 2 - 8 }, AppStyles.middleButton, { height: (width / 2 - 8) * 0.42 }]}>
                                <TouchableHighlight
                                    onPress={() => {
                                        this.props.navigation.navigate('Chat', {
                                            destination: {
                                                latitude: item.shopModel.latitude,
                                                longitude: item.shopModel.longitude
                                            }
                                        })
                                    }}
                                >
                                    <View style={{
                                        flexDirection: 'row', justifyContent: "space-between", borderWidth: 2,
                                        borderColor: "#f0695a", height: (width / 2 - 8) * 0.42, paddingLeft: 5, fontWeight: "bold"
                                    }}>
                                        <View>
                                            <Text style={styles.activeFont}>Route to</Text>
                                            <Text style={styles.activeFont}>Store</Text>
                                        </View>
                                        <View style={[{
                                            borderRadius: 45,
                                            backgroundColor: "#f0695a",
                                            width: 45,
                                            height: 45,
                                            margin: 5,
                                            fontSize: 25
                                        }, styles.center]}>
                                            <Text style={styles.iconStyle}>&#xe602;</Text>
                                        </View>
                                    </View> 
                                </TouchableHighlight>
                            </View>
                            <View style={[AppStyles.middleButtonRight, { width: width / 2 - 8 }, AppStyles.middleButton,
                            { height: (width / 2 - 8) * 0.42 }]}>
                                <TouchableHighlight
                                    onPress={() => {

                                        this.props.navigation.navigate('Chat', {
                                            destination: {
                                                latitude: item.latitude,
                                                longitude: item.longitude
                                            }
                                        })

                                    }}
                                >
                                    <View style={{
                                        flexDirection: 'row', justifyContent: "space-between", borderWidth: 2,
                                        borderColor: "#f0695a", height: (width / 2 - 8) * 0.42, paddingLeft: 5, fontWeight: "bold"
                                    }}>
                                        <View>
                                            <Text style={styles.activeFont}>Route to</Text>
                                            <Text style={styles.activeFont}>Customer</Text>
                                        </View>
                                        <View style={[{
                                            borderRadius: 45,
                                            backgroundColor: "#f0695a",
                                            width: 45,
                                            height: 45,
                                            margin: 5,
                                            fontSize: 25
                                        }, styles.center]}>
                                            <Text style={styles.iconStyle}>&#xe602;</Text>
                                        </View>
                                    </View>
                                </TouchableHighlight>
                            </View>
                        </View>
                    </View>

                    <View style={[AppStyles.middleButton, { marginTop: 5 }]}>
                        <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'space-between', width: width }}>
                            <View style={[AppStyles.middleButtonLeft, { width: width / 2 - 8 },
                            AppStyles.middleButton, { height: (width / 2 - 8) * 0.42,
                                borderBottomColor: "#f7f7f7", borderBottomWidth: 2 }]}>
                                {/* <TouchableHighlight
                                    onPress={() => { this.props.navigation.push('Chat') }}
                                >
                                </TouchableHighlight> */}
                                <View style={{
                                    flexDirection: 'row', justifyContent: "space-between",
                                    height: (width / 2 - 8) * 0.42, paddingLeft: 5, fontWeight: "bold"
                                }}>
                                    <View>
                                        <Text style={styles.activeFont}>Pick Up </Text>
                                        <Text style={[styles.activeFont, { fontWeight: "normal" }]}>
                                            In
                                            {
                                                (item.pickUpEnd -
                                                item.pickUpStart)/ 60000
                                            }
                                            Mins</Text>
                                    </View>
                                </View>
                            </View>
                            {/* <View style={[AppStyles.middleButtonRight,
                            { width: width / 2 - 8 }, AppStyles.middleButton,
                            {
                                height: (width / 2 - 8) * 0.42,
                                backgroundColor: "#f0695a",
                                paddingLeft: 15,
                                paddingTop: 5
                            }]}>
                                <TouchableHighlight
                                    onPress={() => { this.props.navigation.push('Chat') }}
                                >
                                </TouchableHighlight> 
                                <View style={{
                                    flexDirection: 'row', justifyContent: "space-between",
                                    height: (width / 2 - 8) * 0.42, paddingLeft: 5, fontWeight: "bold"
                                }}>
                                    <View>
                                        <Text style={[styles.activeFont, { color: "#ffffff" }]}>Due to Store</Text>
                                        <Text style={[styles.activeFont, { color: "#ffffff" }]}>€{item.driverPaid}</Text>
                                    </View>
                                </View>
                            </View> */}
                            {
                                item.driverPaidStatus ? (<View style={[AppStyles.middleButtonRight,
                                { width: width / 2 - 8 }, AppStyles.middleButton,
                                {
                                    height: (width / 2 - 8) * 0.42,
                                    backgroundColor: "#f0695a",
                                    paddingLeft: 15,
                                    paddingTop: 5
                                }]}>
                                    <View style={{
                                        flexDirection: 'row', justifyContent: "space-between",
                                        height: (width / 2 - 8) * 0.42, paddingLeft: 5, fontWeight: "bold"
                                    }}>
                                        <View>
                                            <Text style={[styles.activeFont, { color: "#ffffff" }]}>Due to Store</Text>
                                            <Text style={[styles.activeFont, { color: "#ffffff" }]}>€{item.driverPaid}</Text>
                                        </View>
                                    </View>
                                </View>) : (<View style={[AppStyles.middleButtonRight,
                                { width: width / 2 - 8 }, AppStyles.middleButton,
                                {
                                    height: (width / 2 - 8) * 0.42,
                                    backgroundColor: "#62a55d",
                                    paddingLeft: 15,
                                    paddingTop: 5
                                }]}>
                                    <View style={{
                                        flexDirection: 'row', justifyContent: "space-between",
                                        height: (width / 2 - 8) * 0.42, paddingLeft: 5, fontWeight: "bold"
                                    }}>
                                        <View>
                                            <Text style={[styles.activeFont, { color: "#ffffff" }]}>
                                                Due to You
                                            </Text>
                                            <Text style={[styles.activeFont, { color: "#ffffff" }]}>
                                                €{item.storePaid}
                                            </Text>
                                        </View>
                                    </View>
                                </View>)
                            }
                        </View>
                    </View>
                    <View style={{ justifyContent: "center", flexDirection: 'row', marginTop: 5 }}>
                        <Text style={[styles.iconStyle, { color: "#ff544f" }]}>&#xe604;</Text>
                        <View style={{ paddingLeft: 5 }}>
                            <Text style={{ width: width * .85 }}>
                                {item.address}
                            </Text>
                        </View>
                    </View>
                    <View style={{ width: width - 16, height: 5 }}></View>
                    <View style={{ width: width - 16, height: 2, backgroundColor: "#f7f7f7" }}></View>
                    <View style={{
                        flex: 1, flexDirection: 'row',
                        justifyContent: 'space-between',
                        width: width - 16, height: 36, paddingLeft: 15, paddingRight: 15
                    }}>
                        <View style={{ height: 36, paddingTop: 8 }}>
                            <Text style={{ fontSize: 20, fontWeight: "bold" }}>{item.time} Mins 
                            ({item.distance} KM)</Text>
                        </View>
                        <View>
                            <Text style={{ fontSize: 25, fontWeight: "bold", color: "#ff544f" }}>
                            €{item.deliverFee}</Text>
                        </View>
                    </View>
                </ScrollView>
                {/* <View style={{
                    width: width - 16, margin: 8, flexDirection: 'row',
                    backgroundColor: "#739e5e",
                    borderRadius: 50
                }}
                >
                    <Svg key={`key-1`} icon={"greenslider-arrow-144x144"}
                        fill="#000000"
                        style={{ width: 50, height: 50 }} />
                    <TouchableHighlight
                        onPress={() => { 
                            Update({
                                orderId:item.orderId,
                                updateStatus: "accepted",
                                status: item.status,
                                driverModel: {
                                    driverId: "d001"   
                                }
                              }).then((data) => {
                                  this.getData()
                            });
                        }}
                        style={{
                            width: width * .6,
                            flex: 0, height: 50,
                            alignItems: 'center',
                            justifyContent: 'center'
                        }}
                    >
                        <Text
                            style={{ fontSize: 38, fontWeight: "bold", color: "#FFFFFF" }}>Accept</Text>
                    </TouchableHighlight>
                </View> */}

                <View style={{
                    flexDirection: 'row',
                    width:width,
                    justifyContent:"center"
                }}>
                    <LineBtn item={item} width={width*.7} title={"Accept"} showDailog={(item)=>{
                        this.showDailog(item, _this);
                    }}>
                    </LineBtn>
                </View> 
                <View style={{ flexDirection: 'row', width: width, justifyContent: "center" }}>

                    <Text style={{
                        color: "#f0695a",
                        fontFamily: 'iconfont'
                    }}>
                        &#xe6bc;
                    </Text>
                    <Text style={{
                        width: 80,
                        justifyContent: "center",
                        textAlign: "center"
                    }}>
                        {windex+index + 1} to {this.state.orderSize}
                    </Text>
                    <Text style={{
                        color: "#f0695a",
                        fontFamily: 'iconfont'
                    }}>
                        &#xe62d;
                    </Text>

                </View>
            </View>
        </TouchableNativeFeedback>
    }
    backScoll() {
        let mainData = this.oData;

        let windex = this.state.windex;

        let sw = this.state.windex;

        this.s = sw;
        if(sw-1 < 0) return false;

        let cData = [mainData[windex-1]];
            this.setState({
                newOrderData:{
                    data: cData
                },
                windex: this.state.windex-1
            })

    }

    goScoll() {
        let mainData = this.oData;

        let windex = this.state.windex+1;

        let data = this.oData.length;

        let sw = this.state.windex+1;

        this.s = sw;
        if(sw<data) {
            let cData = [mainData[windex]];

            // alert(JSON.stringify(cData));
            this.setState({
                newOrderData:{
                    data: cData
                },
                windex: windex
            })
        }
    }
    // backScoll() {
    //     let mainData = this.oData;

    //     let windex = (this.state.windex - 1) * 5;

    //     let data = this.oData.length / 5;
    //     if (data < 1) return false;
    //     let dataL = parseInt(data);
    //     if (data > dataL) dataL = dataL + 1;

    //     let sw = this.state.windex - 1;

    //     if(sw==0) return false;
    //     if (sw < dataL) {
    //         let cData = [mainData[windex - 5], mainData[windex - 4], mainData[windex - 3], mainData[windex - 2], mainData[windex - 1]];

    //         this.setState({
    //             newOtherOrderData: {
    //                 data: cData
    //             },
    //             windex: this.state.windex - 1
    //         })
    //     }

    // }

    // goScoll() {
    //     // let mainData = this.state.newOtherOrderData.data;
    //     let mainData = this.oData;

    //     let windex = (this.state.windex + 1) * 5;

    //     let data = this.oData.length / 5;

    //     // let data = this.state.newOtherOrderData.data.length/5;
    //     let dataL = parseInt(data);
    //     if (data > dataL) dataL = dataL + 1;

    //     let sw = this.state.windex + 1;

    //     if (sw < dataL) {
    //         let cData = [];
    //         if (data > dataL) {
    //             // let Data1 = null,Data2= null,Data3= null,Data4= null,Data5= null

    //             cData = [];
    //             if (mainData[windex + 1]) cData[0] = mainData[windex + 1];

    //             if (mainData[windex + 2]) cData[1] = mainData[windex + 2];

    //             if (mainData[windex + 3]) cData[2] = mainData[windex + 3];

    //             if (mainData[windex + 4]) cData[3] = mainData[windex + 4];

    //             if (mainData[windex + 5]) cData[4] = mainData[windex + 5];



    //         } else {
    //             cData = [mainData[windex + 1], mainData[windex + 2], mainData[windex + 3], mainData[windex + 4], mainData[windex + 5]];

    //         }

    //         this.setState({
    //             newOtherOrderData: {
    //                 data: cData
    //             },
    //             windex: this.state.windex + 1
    //         })
    //     }
    // }

    /**
     * @render
     * @returns {*}
     */
    render() {
        let initialOffset = {
            x: this._getScrollAmount(this.state.index, this.state.orderSize),
            y: 0,
        }
        
        return (<View style={{width:width,height:height-170}}>
                {
                    this.state.showOtherOrders ? (
                        this.state.newOtherOrderData ?
                            <View style={styles.scroll}>
                                <Animated.ScrollView
                                    horizontal
                                    keyboardShouldPersistTaps="handled"
                                    bounces={true}
                                    alwaysBounceHorizontal={true}
                                    scrollsToTop={true}
                                    showsHorizontalScrollIndicator={false}
                                    automaticallyAdjustContentInsets={false}
                                    // canCancelContentTouches={true}
                                    // overScrollMode="never"
                                    scrollTo={{ x: 0, y: 0 }}
                                    pagingEnabled={true}
                                    contentOffset={initialOffset}
                                    // onScroll={this.handleScroll.bind(this)}
                                    // refreshControl={data=>alert(data)}
                                    removeClippedSubviews
                                    alwaysBounce={true}
                                    bouncesZoom={true}
                                    ref='_scrollView'
                                    onScrollEndDrag={(event) => {
                                        // alert(JSON.stringify(event.nativeEvent.contentOffset.x));
                                        if(event.nativeEvent.velocity.x >= 0 )this.backScoll();
                                        if(event.nativeEvent.velocity.x < 0 ) {
                                            this.goScoll();
                                        }
                                    }}
                                >
                                    {JSON.parse(JSON.stringify(this.state.newOtherOrderData))
                                        .data.map((data,index) => this._rederOtherData(data,index))}
                                </Animated.ScrollView>
                            </View> : null
                    ) : (
                            <View>
                                <View style={{
                                    marginTop: 50,
                                    width: width,
                                    justifyContent: "center",
                                    textAlign: "center"
                                }}>
                                    <Text style={{
                                        width: width,
                                        justifyContent: "center",
                                        textAlign: "center"
                                    }}>
                                        Work as a store driver start here
                                    </Text>

                                    <View style={{
                                        marginTop: 60, width: width - 16, margin: 8, flexDirection: 'row',
                                        backgroundColor: "#739e5e",
                                        borderRadius: 50
                                    }}
                                    >
                                        <Svg key={`key-1`} icon={"greenslider-arrow-144x144"}
                                            fill="#000000"
                                            style={{ width: 50, height: 50 }} />
                                        <TouchableHighlight
                                            onPress={() => {
                                                this.startShift()
                                            }}

                                            style={{
                                                width: width * .6,
                                                flex: 0, height: 50,
                                                alignItems: 'center',
                                                justifyContent: 'center'
                                            }}
                                        >
                                            <Text
                                                style={{ fontSize: 38, fontWeight: "bold", color: "#FFFFFF" }}>Start Shift</Text>
                                        </TouchableHighlight>
                                    </View>

                                </View>
                            </View>
                        )
                }
            </View>
        )
    }
}
const styles = StyleSheet.create({
    defWidth: {
        width: width / 2 - 8
    },
    defHeight: {
        width: (width / 2 - 8) * 0.42
    },
    iconStyle: {
        color: '#ffffff',
        fontFamily: 'iconfont',
        fontSize: 20
    },
    iconStyleSM: {
        color: '#ffffff',
        fontFamily: 'iconfont',
        fontSize: 16
    },
    activeFont: {
        fontSize: 24,
        fontWeight: "bold",
        color: "#000000"
    },

    lineFont: {
        fontSize: 16,
        color: "#000000",
        paddingLeft: 5
    },
    center: {

        textAlign: 'center',
        alignItems: 'center',
        justifyContent: 'center',
        textAlignVertical: 'center'
    }
})
export default ChinaTown;